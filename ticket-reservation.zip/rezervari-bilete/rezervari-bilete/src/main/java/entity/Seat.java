package entity;

import io.quarkus.hibernate.orm.panache.PanacheEntity;
import jakarta.persistence.Entity;

@Entity
public class Seat extends PanacheEntity {

    public String tipZona;
    public String numeZona;
    public String sector;
    public int rand;
    public int loc;
    public double pret;
    public boolean isReserved;

    @Override
    public String toString() {
        String stare = isReserved ? "[OCUPAT]" : "[LIBER]";
        return String.format("ID:%d | %s | %s | Sector %s | Rand %d | Loc %d | %.0f RON %s",
                id, numeZona, tipZona, sector, rand, loc, pret, stare);
    }
}
