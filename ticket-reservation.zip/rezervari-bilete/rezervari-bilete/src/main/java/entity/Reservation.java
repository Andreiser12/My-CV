package entity;

import io.quarkus.hibernate.orm.panache.PanacheEntity;
import jakarta.persistence.Entity;
import jakarta.transaction.Transactional;

import java.time.LocalDateTime;

@Entity
public class Reservation extends PanacheEntity {

    public String numeClient;
    public Long seatId;
    public LocalDateTime dataRezervarii;
    public Reservation() {}
    public Reservation(String numeClient, Long seatId) {
        this.numeClient = numeClient;
        this.seatId = seatId;
        this.dataRezervarii = LocalDateTime.now();
    }
}
