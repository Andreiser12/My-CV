package server;

import org.acme.ShopService;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;
import java.util.UUID;
public class ClientHandler extends Thread {

    private final Socket socket;
    private final ShopService shopService;
    private final String clientName;

    public ClientHandler(Socket socket, ShopService shopService) {
        this.socket = socket;
        this.shopService = shopService;
        this.clientName = "Client-" + UUID.randomUUID().toString().substring(0, 4);
    }

    @Override
    public void run() {
        System.out.println(">>> S-a conectat: " + clientName);

        try (
                BufferedReader in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
                PrintWriter out = new PrintWriter(socket.getOutputStream(), true)
        ) {
            out.println("BINE AI VENIT LA STADION! Esti identificat ca: " + clientName);
            out.println("Comenzi: LIST, RESERVE <id>, MY, CANCEL <id_rezervare>, EXIT");
            out.println("---END---");

            String request;
            while ((request = in.readLine()) != null) {
                String response = handleRequest(request);
                out.println(response);
                out.println("---END---");

                if (request.trim().equalsIgnoreCase("EXIT")) {
                    break;
                }
            }

        } catch (IOException e) {
            System.out.println("Eroare conexiune cu " + clientName);
        } finally {
            try {
                socket.close();
            } catch (IOException e) { e.printStackTrace(); }
            System.out.println("<<< Deconectat: " + clientName);
        }
    }

    private String handleRequest(String request) {
        String[] parts = request.trim().split("\\s+");
        String command = parts[0].toUpperCase();

        try {
            switch (command) {
                case "LIST":
                    return shopService.getAvailableSeats();

                case "RESERVE":
                    if (parts.length < 2) return "EROARE: Specifica ID-ul locului (ex: RESERVE 10)";
                    Long seatId = Long.parseLong(parts[1]);
                    return shopService.reserveSeat(seatId, clientName);

                case "MY":
                    return shopService.getMyReservations(clientName);

                case "CANCEL":
                    if (parts.length < 2) return "EROARE: Specifica ID-ul rezervarii (ex: CANCEL 5)";
                    Long resId = Long.parseLong(parts[1]);
                    return shopService.cancelReservation(resId, clientName);

                case "EXIT":
                    return "La revedere!";

                default:
                    return "Comanda necunoscuta. Incearca: LIST, RESERVE, MY, CANCEL, EXIT";
            }
        } catch (NumberFormatException e) {
            return "EROARE: ID-ul trebuie sa fie un numar valid!";
        } catch (Exception e) {
            return "EROARE SERVER: " + e.getMessage();
        }
    }
}
