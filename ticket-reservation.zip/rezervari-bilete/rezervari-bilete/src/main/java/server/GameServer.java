package server;

import io.quarkus.runtime.StartupEvent;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.enterprise.event.Observes;
import jakarta.inject.Inject;
import org.acme.ShopService;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

@ApplicationScoped
public class GameServer {

    @Inject
    ShopService shopService;

    public void start(@Observes StartupEvent ev) {
        new Thread(() -> {
            try (ServerSocket serverSocket = new ServerSocket(8088)) {
                System.out.println("==========================================");
                System.out.println(" SERVER STADION PORNIT PE PORTUL 8088 ");
                System.out.println("==========================================");

                while (true) {
                    Socket clientSocket = serverSocket.accept();
                    new ClientHandler(clientSocket, shopService).start();
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
        }).start();
    }
}
