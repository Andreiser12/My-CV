package org.acme;

import jakarta.enterprise.context.ApplicationScoped;
import jakarta.transaction.Transactional;
import entity.Reservation;
import entity.Seat;

import java.util.List;
import java.util.stream.Collectors;

@ApplicationScoped
public class ShopService {
    @Transactional
    public String getAvailableSeats() {
        List<Seat> seats = Seat.list("isReserved = ?1 ORDER BY id", false);

        if (seats.isEmpty()) {
            return "Ne pare rau, nu mai sunt locuri libere!";
        }

        StringBuilder sb = new StringBuilder("LOCURI DISPONIBILE:\n");
        for (Seat s : seats) {
            sb.append(s.toString()).append("\n");
        }
        return sb.toString();
    }

    @Transactional
    public synchronized String reserveSeat(Long seatId, String clientName) {
        Seat seat = Seat.findById(seatId);

        if (seat == null) {
            return "EROARE: Locul cu ID " + seatId + " nu exista.";
        }

        if (seat.isReserved) {
            return "EROARE: Imi pare rau, locul " + seatId + " este deja OCUPAT de altcineva!";
        }

        seat.isReserved = true;
        seat.persistAndFlush();

        Reservation res = new Reservation(clientName, seatId);
        res.persistAndFlush();

        return ">>> REZERVARE REUSITA! Locul " + seatId + " (" + seat.numeZona + ") este acum al tau.";
    }

    @Transactional
    public String getMyReservations(String clientName) {
        List<Reservation> myRes = Reservation.list("numeClient", clientName);

        if (myRes.isEmpty()) {
            return "Nu ai nicio rezervare activa.";
        }

        StringBuilder sb = new StringBuilder("REZERVARILE TALE (" + clientName + "):\n");
        for (Reservation r : myRes) {
            Seat s = Seat.findById(r.seatId);
            sb.append("Rezervare ID:").append(r.id)
                    .append(" -> ").append(s.toString())
                    .append("\n");
        }
        return sb.toString();
    }

    @Transactional
    public String cancelReservation(Long reservationId, String clientName) {
        Reservation res = Reservation.findById(reservationId);

        if (res == null) {
            res = Reservation.find("seatId = ?1 and numeClient = ?2", reservationId, clientName).firstResult();
        }

        if (res == null) {
            return "EROARE: Rezervarea nu a fost gasita (poti folosi ID Rezervare sau ID Loc).";
        }

        if (!res.numeClient.equals(clientName)) {
            return "EROARE: Nu poti anula rezervarea altcuiva!";
        }

        Seat seat = Seat.findById(res.seatId);
        if (seat != null) {
            seat.isReserved = false;
            seat.persist();
        }
        res.delete();

        return "SUCCES: Rezervarea a fost anulata, locul este din nou liber.";
    }
}
