package org.acme;

import io.quarkus.runtime.StartupEvent;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.enterprise.event.Observes;
import jakarta.transaction.Transactional;
import entity.Seat;

@ApplicationScoped
public class DataInitialization {

    @Transactional
    public void init(@Observes StartupEvent event) {
        if (Seat.count() > 0) {
            return;
        }

        System.out.println(">>> [INIT] Se generează stadionul...");

        for (int i = 1; i <= 2; i++) {
            String numeTribuna = "Tribuna " + i;
            // Generăm Sector A și Sector B
            genereazaLocuri("TRIBUNA", numeTribuna, "A", 50.0);
            genereazaLocuri("TRIBUNA", numeTribuna, "B", 50.0);
        }

        genereazaLocuri("PELUZA", "Peluza Gazde", "Unic", 20.0);
        genereazaLocuri("PELUZA", "Peluza Oaspeti", "Unic", 20.0);
        System.out.println(">>> [INIT] Stadion generat cu succes! Total locuri: " + Seat.count());
    }

    private void genereazaLocuri(String tip, String nume, String sector, double pret) {
        for (int r = 1; r <= 5; r++)
        {
            for (int l = 1; l <= 10; l++)
            {
                Seat s = new Seat();
                s.tipZona = tip;
                s.numeZona = nume;
                s.sector = sector;
                s.rand = r;
                s.loc = l;
                s.pret = pret;
                s.isReserved = false;
                s.persist();
            }
        }
    }
}
