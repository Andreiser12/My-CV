#ifndef EDGE_H
#define EDGE_H

class Edge
{
public:
    Edge();
    Edge(int from, int to, int cost);

    int GetFrom() const;
    int GetTo() const;
    int GetCost() const;

private:

    int m_from;
    int m_to;
    int m_cost;
};

#endif // EDGE_H
