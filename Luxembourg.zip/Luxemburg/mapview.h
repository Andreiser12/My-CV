#ifndef MAPVIEW_H
#define MAPVIEW_H
#include "graph.h"

class MapView
{
public:
    MapView();

private:


};

#endif // MAPVIEW_H
