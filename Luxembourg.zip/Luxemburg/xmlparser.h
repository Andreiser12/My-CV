#ifndef XMLPARSER_H
#define XMLPARSER_H
#include <QString>
#include <QDebug>
#include "Graph.h"
#include <QFile>
#include <QXmlStreamReader>

class XMLParser
{
public:
    XMLParser();
   static void ReadFromXMLFile(const QString& fileName, Graph& graph);

private:

};

#endif // XMLPARSER_H
