#include "xmlparser.h"

XMLParser::XMLParser() {}

void XMLParser::ReadFromXMLFile(const QString &fileName, Graph &graph)
{
    QFile file(fileName);

    if(!file.open(QIODevice::ReadOnly | QIODevice::Text))
    {
        qDebug() <<"Fisierul nu a putut fi citit.";
        return;
    }

    QXmlStreamReader xml(&file);
    while(!xml.atEnd() && !xml.hasError())
    {
        xml.readNext();
        if(xml.isStartElement() && xml.name() == "node")
        {
            auto attributes = xml.attributes();
            Node node(attributes.value("id").toInt(), attributes.value("latitude").toInt(), attributes.value("longitude").toInt());
            graph.AddNode(node);
        }
        else if(xml.isStartElement() && xml.name() =="arc")
        {
            auto attributes = xml.attributes();
            Edge edge(attributes.value("from").toInt(), attributes.value("to").toInt(), attributes.value("length").toInt());
            graph.AddEdge(edge);
        }
    }
    if(!xml.atEnd())
    {
        qDebug() <<"Fisierul a fost citit cu erori.";
        return;
    }
    file.close();
}
