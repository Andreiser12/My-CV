#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QGraphicsScene>
#include <QGraphicsView>
#include "graph.h"
#include "kdtree.h"

QT_BEGIN_NAMESPACE
namespace Ui { class MainWindow; }
QT_END_NAMESPACE

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

    void DrawMap();
    void DrawPath();
    void HighlightNode(int nodeId, bool isStart);

protected:
    bool eventFilter(QObject *obj, QEvent *event) override;
    void showEvent(QShowEvent *event) override;

private:
    Ui::MainWindow *ui;
    Graph m_graph;
    QGraphicsScene* m_scene;
    QGraphicsView* m_view;
    KDTree m_kdTree;

    int m_startNodeId = -1;
    int m_endNodeId = -1;
    bool m_firstShow = true;
    QGraphicsEllipseItem* m_startMarker = nullptr;
    QGraphicsEllipseItem* m_endMarker = nullptr;
    std::vector<QGraphicsLineItem*> m_pathLines;


};
#endif // MAINWINDOW_H
