#include "mainwindow.h"
#include "./ui_mainwindow.h"
#include "xmlparser.h"
#include <QDebug>
#include <QGraphicsEllipseItem>
#include <QGraphicsLineItem>
#include <QGraphicsScene>
#include <QGraphicsView>
#include <QMouseEvent>


MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent), ui(new Ui::MainWindow) {
  ui->setupUi(this);

  m_scene = new QGraphicsScene(this);
  m_view = new QGraphicsView(m_scene, this);
  setCentralWidget(m_view);

  XMLParser::ReadFromXMLFile("Harta_Luxemburg.xml", m_graph);

  std::vector<Node> allNodes;
  for (const auto &pair : m_graph.GetNodes()) {
    allNodes.push_back(pair.second);
  }
  m_kdTree.Build(allNodes);

  DrawMap();

  m_view->viewport()->installEventFilter(this);
  m_view->setDragMode(QGraphicsView::ScrollHandDrag);
}

MainWindow::~MainWindow()
{
    delete ui;
}

bool MainWindow::eventFilter(QObject *obj, QEvent *event)
{
    if (obj == m_view->viewport() && event->type() == QEvent::MouseButtonPress)
    {
        QMouseEvent *mouseEvent = static_cast<QMouseEvent *>(event);

        if (mouseEvent->button() == Qt::RightButton)
        {
            QPointF scenePos = m_view->mapToScene(mouseEvent->pos());

            Node nearest = m_kdTree.FindNearest((int)scenePos.x(), (int)(-scenePos.y()));

            if (nearest.GetId() != 0)
            {
                if (m_startNodeId == -1)
                {
                    m_startNodeId = nearest.GetId();
                    HighlightNode(m_startNodeId, true);
                }
                else if (m_endNodeId == -1)
                {
                    m_endNodeId = nearest.GetId();
                    HighlightNode(m_endNodeId, false);
                    DrawPath();
                }
                else
                {
                    m_startNodeId = nearest.GetId();
                    m_endNodeId = -1;

                    if (m_startMarker)
                    {
                        m_scene->removeItem(m_startMarker);
                        delete m_startMarker;
                        m_startMarker = nullptr;
                    }
                    if (m_endMarker)
                    {
                        m_scene->removeItem(m_endMarker);
                        delete m_endMarker;
                        m_endMarker = nullptr;
                    }
                    for (auto line : m_pathLines)
                    {
                        m_scene->removeItem(line);
                        delete line;
                    }
                    m_pathLines.clear();

                    HighlightNode(m_startNodeId, true);
                }
            }
            return true;
        }

    }

    if (obj == m_view->viewport() && event->type() == QEvent::Wheel)
    {
        QWheelEvent *wheelEvent = static_cast<QWheelEvent *>(event);

        const double scaleFactor = 1.15;

        if (wheelEvent->angleDelta().y() > 0)
            m_view->scale(scaleFactor, scaleFactor);
        else
            m_view->scale(1.0 / scaleFactor, 1.0 / scaleFactor);

        return true;
    }

    return QMainWindow::eventFilter(obj, event);
}

void MainWindow::showEvent(QShowEvent *event)
{
    QMainWindow::showEvent(event);

    if (m_firstShow)
    {
        if (m_scene)
        {
            QRectF mapBoundingRect = m_scene->itemsBoundingRect();
            m_scene->setSceneRect(mapBoundingRect);
            m_view->fitInView(mapBoundingRect, Qt::KeepAspectRatio);
        }

        m_firstShow = false;
    }
}

void MainWindow::DrawMap()
{
  if (!m_scene)
    {
        return;
    }
  m_scene->clear();
  m_pathLines.clear();
  m_startMarker = nullptr;
  m_endMarker = nullptr;

  QPen pen(Qt::blue);
  pen.setWidth(0);

  for (const auto &edge : m_graph.GetEdges())
  {
    const Node *first = m_graph.GetNode(edge.GetFrom());
    const Node *second = m_graph.GetNode(edge.GetTo());

    if (first && second)
    {
      m_scene->addLine(first->GetLongitude(), -first->GetLatitude(), second->GetLongitude(), -second->GetLatitude(), pen);
    }
  }
}

void MainWindow::HighlightNode(int nodeId, bool isStart)
{
  const Node *n = m_graph.GetNode(nodeId);
  if (!n)
  {
      return;
  }

  QPen pen(isStart ? Qt::green : Qt::red);
  QBrush brush(isStart ? Qt::green : Qt::red);

  double r = 50.0;
  QGraphicsEllipseItem *item = m_scene->addEllipse(n->GetLongitude() - r, -n->GetLatitude() - r, 2 * r, 2 * r, pen, brush);

  item->setZValue(10);
  if (isStart)
  {
    m_startMarker = item;
  }
  else
  {
    m_endMarker = item;
  }
}

void MainWindow::DrawPath()
{
    if (m_startNodeId == -1 || m_endNodeId == -1)
    {
        return;
    }

    std::vector<int> path = m_graph.Dijkstra(m_startNodeId, m_endNodeId);

    if (path.size() < 2)
    {
        return;
    }


    QPen pathPen(QColor(27, 168, 15));

    pathPen.setWidth(4);

    pathPen.setCosmetic(true);

    pathPen.setCapStyle(Qt::RoundCap);
    pathPen.setJoinStyle(Qt::RoundJoin);

    for (size_t i = 0; i < path.size() - 1; i++)
    {
        const Node *u = m_graph.GetNode(path[i]);
        const Node *v = m_graph.GetNode(path[i + 1]);

        if (u && v)
        {
            QGraphicsLineItem *line = m_scene->addLine(
                u->GetLongitude(), -u->GetLatitude(),
                v->GetLongitude(), -v->GetLatitude(),
                pathPen
                );

            line->setZValue(100);

            m_pathLines.push_back(line);
        }
    }
}
