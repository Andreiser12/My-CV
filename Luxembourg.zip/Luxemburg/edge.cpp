#include "edge.h"

Edge::Edge() {}

Edge::Edge(int from, int to, int cost) : m_from{from}, m_to{to}, m_cost{cost} {}

int Edge::GetFrom() const
{
    return m_from;
}

int Edge::GetTo() const
{
    return m_to;
}

int Edge::GetCost() const
{
    return m_cost;
}
