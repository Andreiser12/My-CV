#include "graph.h"
#include <queue>
#include <algorithm>
#include <limits>

using NodeId = int;
using Distance = long long;
using DistanceNodePair = std::pair<Distance, NodeId>;
using DijkstraPriorityQueue = std::priority_queue<DistanceNodePair, std::vector<DistanceNodePair>, std::greater<DistanceNodePair>>;

Graph::Graph() {}

const std::vector<Edge>& Graph::GetEdges() const
{
    return m_edges;
}

const std::unordered_map<NodeId, Node>& Graph::GetNodes() const
{
    return m_nodes;
}

const Node* Graph::GetNode(NodeId id) const
{
    auto it = m_nodes.find(id);
    if (it != m_nodes.end())
    {
        return &it->second;
    }
    return nullptr;
}

void Graph::AddNode(const Node& node)
{
    m_nodes[node.GetId()] = node;
}

void Graph::AddEdge(const Edge& edge)
{
    m_edges.push_back(edge);
    m_adjList[edge.GetFrom()].push_back({edge.GetTo(), edge.GetCost()});
}

std::vector<int> Graph::Dijkstra(NodeId startId, NodeId endId) const
{
    std::unordered_map<NodeId, Distance> shortestDistances;
    std::unordered_map<NodeId, NodeId> parents;
    
    DijkstraPriorityQueue priorityQueue;

    for (const auto& pair : m_nodes)
    {
        shortestDistances[pair.first] = std::numeric_limits<Distance>::max();
    }

    shortestDistances[startId] = 0;
    priorityQueue.push({0, startId});

    while (!priorityQueue.empty())
    {
        Distance currentDistance = priorityQueue.top().first;
        NodeId currentNode = priorityQueue.top().second;
        priorityQueue.pop();

        if (currentDistance > shortestDistances[currentNode])
        {
            continue;
        }

        if (currentNode == endId)
        {
            break;
        }

        if (m_adjList.find(currentNode) != m_adjList.end())
        {
            for (const auto& edge : m_adjList.at(currentNode))
            {
                NodeId vecin = edge.first;
                Distance cost = edge.second;

                if (shortestDistances[currentNode] + cost < shortestDistances[vecin])
                {
                    shortestDistances[vecin] = shortestDistances[currentNode] + cost;
                    parents[vecin] = currentNode;
                    priorityQueue.push({shortestDistances[vecin], vecin});
                }
            }
        }
    }

    std::vector<NodeId> path;
    if (shortestDistances[endId] == std::numeric_limits<Distance>::max())
    {
        return path;
    }

    NodeId currentNode = endId;
    while (currentNode != startId)
    {
        path.push_back(currentNode);
        currentNode = parents[currentNode];
    }
    path.push_back(startId);
    std::reverse(path.begin(), path.end());
    return path;
}
