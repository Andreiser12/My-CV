#include "kdtree.h"
#include <limits>

using Coordinate = int;
using DistanceSquared = long long;

KDTree::KDTree() : m_root(nullptr) {}

KDTree::~KDTree()
{
    DeleteRecursive(m_root);
}

void KDTree::DeleteRecursive(KDNode* node)
{
    if (node == nullptr)
    {
        return;
    }
    DeleteRecursive(node->left);
    DeleteRecursive(node->right);
    delete node;
}

void KDTree::Build(const std::vector<Node>& nodes)
{
    std::vector<Node> copyNodes = nodes;
    m_root = BuildRecursive(copyNodes, 0);
}

KDNode* KDTree::BuildRecursive(std::vector<Node>& nodes, int currentDepth)
{
    if (nodes.empty())
    {
        return nullptr;
    }

    int splitAxis = currentDepth % 2;
    int medianIndex = nodes.size() / 2;

    std::nth_element(nodes.begin(), nodes.begin() + medianIndex, nodes.end(), [splitAxis](const Node& a, const Node& b) {
        if (splitAxis == 0) return a.GetLongitude() < b.GetLongitude();
        return a.GetLatitude() < b.GetLatitude();
    });

    KDNode* currentNode = new KDNode(nodes[medianIndex]);
    
    std::vector<Node> leftNodes(nodes.begin(), nodes.begin() + medianIndex);
    std::vector<Node> rightNodes(nodes.begin() + medianIndex + 1, nodes.end());

    currentNode->left = BuildRecursive(leftNodes, currentDepth + 1);
    currentNode->right = BuildRecursive(rightNodes, currentDepth + 1);

    return currentNode;
}

Node KDTree::FindNearest(Coordinate x, Coordinate y)
{
    if (!m_root)
    {
        return Node();
    }
    KDNode* closestNode = nullptr;
    DistanceSquared shortestDistance = std::numeric_limits<DistanceSquared>::max();
    NearestRecursive(m_root, x, y, 0, closestNode, shortestDistance);
    return closestNode ? closestNode->node : Node();
}

DistanceSquared KDTree::CalculateSquaredDistance(const Node& n, Coordinate x, Coordinate y)
{
    long long dx = (long long)n.GetLongitude() - x;
    long long dy = (long long)n.GetLatitude() - y;
    return dx * dx + dy * dy;
}

void KDTree::NearestRecursive(KDNode* currentNode, Coordinate x, Coordinate y, int currentDepth, KDNode*& closestNode, DistanceSquared& shortestDistance)
{
    if (!currentNode)
    {
        return;
    }

    DistanceSquared currentDistance = CalculateSquaredDistance(currentNode->node, x, y);
    if (currentDistance < shortestDistance)
    {
        shortestDistance = currentDistance;
        closestNode = currentNode;
    }

    int splitAxis = currentDepth % 2;
    int distanceToAxis = (splitAxis == 0) ? (x - currentNode->node.GetLongitude()) : (y - currentNode->node.GetLatitude());

    KDNode* nearestSubtree = (distanceToAxis < 0) ? currentNode->left : currentNode->right;
    KDNode* furthestSubtree = (distanceToAxis < 0) ? currentNode->right : currentNode->left;

    NearestRecursive(nearestSubtree, x, y, currentDepth + 1, closestNode, shortestDistance);

    if ((long long)distanceToAxis * distanceToAxis < shortestDistance)
    {
        NearestRecursive(furthestSubtree, x, y, currentDepth + 1, closestNode, shortestDistance);
    }
}
