#ifndef GRAPH_H
#define GRAPH_H
#include "node.h"
#include "edge.h"
#include <unordered_map>
#include <vector>

class Graph
{
public:
    Graph();
    const std::vector<Edge>& GetEdges() const;
    const std::unordered_map<int, Node>& GetNodes() const;
    const Node* GetNode(int id) const;

    void AddNode(const Node& node);
    void AddEdge(const Edge& edge);

    std::vector<int> Dijkstra(int startId, int endId) const;

private:
    std::unordered_map<int, Node> m_nodes;
    std::vector<Edge> m_edges;
    std::unordered_map<int, std::vector<std::pair<int, int>>> m_adjList;
};

#endif // GRAPH_H
