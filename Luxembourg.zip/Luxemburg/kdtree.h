#ifndef KDTREE_H
#define KDTREE_H

#include "node.h"
#include <vector>
#include <algorithm>
#include <cmath>

struct KDNode {
    Node node;
    KDNode* left;
    KDNode* right;

    KDNode(Node n) : node(n), left(nullptr), right(nullptr) {}
};

class KDTree
{
public:
    KDTree();
    ~KDTree();
    void Build(const std::vector<Node>& nodes);
    Node FindNearest(int x, int y);
    KDNode* BuildRecursive(std::vector<Node>& nodes, int currentDepth);
    void DeleteRecursive(KDNode* node);
    void NearestRecursive(KDNode* root, int x, int y, int depth, KDNode*& best, long long& bestDist);
    long long CalculateSquaredDistance(const Node& n, int x, int y);

private:
    KDNode* m_root;

};

#endif // KDTREE_H
