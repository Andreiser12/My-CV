#include "node.h"

Node::Node() {}

Node::Node(int id, int latitude, int longitude) : m_id{id}, m_longitude{longitude}, m_latitude{latitude} {}

int Node::GetId() const
{
    return m_id;
}

int Node::GetLongitude() const
{
    return m_longitude;
}

int Node::GetLatitude() const
{
    return m_latitude;
}
