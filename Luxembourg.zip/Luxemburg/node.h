#ifndef NODE_H
#define NODE_H

class Node
{
public:
    Node();
    Node(int id, int latitude, int longitude);

    int GetId() const;
    int GetLongitude() const;
    int GetLatitude() const;

private:

    int m_id;
    int m_longitude;
    int m_latitude;
};

#endif // NODE_H
