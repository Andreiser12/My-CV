// Generated from c:/Users/razva/Desktop/An2/LFC/Tema2/CompilatorLFC.g4 by ANTLR 4.13.1
import org.antlr.v4.runtime.atn.*;
import org.antlr.v4.runtime.dfa.DFA;
import org.antlr.v4.runtime.*;
import org.antlr.v4.runtime.misc.*;
import org.antlr.v4.runtime.tree.*;
import java.util.List;
import java.util.Iterator;
import java.util.ArrayList;

@SuppressWarnings({"all", "warnings", "unchecked", "unused", "cast", "CheckReturnValue"})
public class CompilatorLFCParser extends Parser {
	static { RuntimeMetaData.checkVersion("4.13.1", RuntimeMetaData.VERSION); }

	protected static final DFA[] _decisionToDFA;
	protected static final PredictionContextCache _sharedContextCache =
		new PredictionContextCache();
	public static final int
		INT=1, FLOAT=2, DOUBLE=3, STRING=4, CONST=5, VOID=6, IF=7, ELSE=8, FOR=9, 
		WHILE=10, RETURN=11, LESS_OR_EQUAL=12, GREATER_OR_EQUAL=13, EQUAL=14, 
		LESS_THAN=15, GREATER_THAN=16, NOT_EQUAL=17, AND=18, OR=19, NOT=20, ADD_ASSIGN=21, 
		SUB_ASSIGN=22, MUL_ASSIGN=23, DIV_ASSIGN=24, MOD_ASSIGN=25, ASSIGN=26, 
		INCREMENT=27, DECREMENT=28, PLUS=29, MINUS=30, MUL=31, DIV=32, MOD=33, 
		OPEN_PARAM=34, CLOSE_PARAM=35, CURLY_OPEN_BRACKET=36, CURLY_CLOSE_BRACKET=37, 
		COMMA=38, SEMI=39, INT_LITERAL=40, FLOAT_LITERAL=41, DOUBLE_LITERAL=42, 
		STRING_LITERAL=43, MAIN=44, ID=45, COMMENT_LINE=46, COMMENT=47, WS=48;
	public static final int
		RULE_program = 0, RULE_global_decl = 1, RULE_main_function = 2, RULE_function = 3, 
		RULE_func_decl = 4, RULE_func_type = 5, RULE_param_list = 6, RULE_param = 7, 
		RULE_block = 8, RULE_statement = 9, RULE_var_decl = 10, RULE_var_type = 11, 
		RULE_return_statement = 12, RULE_if_statement = 13, RULE_condition = 14, 
		RULE_relational_op = 15, RULE_logical_op = 16, RULE_assign_op = 17, RULE_assignment_statement = 18, 
		RULE_while_statement = 19, RULE_for_statement = 20, RULE_for_init = 21, 
		RULE_for_condition = 22, RULE_for_step = 23, RULE_assignment_statement_no_semi = 24, 
		RULE_expr = 25, RULE_function_call = 26, RULE_argument_list = 27;
	private static String[] makeRuleNames() {
		return new String[] {
			"program", "global_decl", "main_function", "function", "func_decl", "func_type", 
			"param_list", "param", "block", "statement", "var_decl", "var_type", 
			"return_statement", "if_statement", "condition", "relational_op", "logical_op", 
			"assign_op", "assignment_statement", "while_statement", "for_statement", 
			"for_init", "for_condition", "for_step", "assignment_statement_no_semi", 
			"expr", "function_call", "argument_list"
		};
	}
	public static final String[] ruleNames = makeRuleNames();

	private static String[] makeLiteralNames() {
		return new String[] {
			null, "'int'", "'float'", "'double'", "'string'", "'const'", "'void'", 
			"'if'", "'else'", "'for'", "'while'", "'return'", "'<='", "'>='", "'=='", 
			"'<'", "'>'", "'!='", "'&&'", "'||'", "'!'", "'+='", "'-='", "'*='", 
			"'/='", "'%='", "'='", "'++'", "'--'", "'+'", "'-'", "'*'", "'/'", "'%'", 
			"'('", "')'", "'{'", "'}'", "','", "';'", null, null, null, null, "'main'"
		};
	}
	private static final String[] _LITERAL_NAMES = makeLiteralNames();
	private static String[] makeSymbolicNames() {
		return new String[] {
			null, "INT", "FLOAT", "DOUBLE", "STRING", "CONST", "VOID", "IF", "ELSE", 
			"FOR", "WHILE", "RETURN", "LESS_OR_EQUAL", "GREATER_OR_EQUAL", "EQUAL", 
			"LESS_THAN", "GREATER_THAN", "NOT_EQUAL", "AND", "OR", "NOT", "ADD_ASSIGN", 
			"SUB_ASSIGN", "MUL_ASSIGN", "DIV_ASSIGN", "MOD_ASSIGN", "ASSIGN", "INCREMENT", 
			"DECREMENT", "PLUS", "MINUS", "MUL", "DIV", "MOD", "OPEN_PARAM", "CLOSE_PARAM", 
			"CURLY_OPEN_BRACKET", "CURLY_CLOSE_BRACKET", "COMMA", "SEMI", "INT_LITERAL", 
			"FLOAT_LITERAL", "DOUBLE_LITERAL", "STRING_LITERAL", "MAIN", "ID", "COMMENT_LINE", 
			"COMMENT", "WS"
		};
	}
	private static final String[] _SYMBOLIC_NAMES = makeSymbolicNames();
	public static final Vocabulary VOCABULARY = new VocabularyImpl(_LITERAL_NAMES, _SYMBOLIC_NAMES);

	/**
	 * @deprecated Use {@link #VOCABULARY} instead.
	 */
	@Deprecated
	public static final String[] tokenNames;
	static {
		tokenNames = new String[_SYMBOLIC_NAMES.length];
		for (int i = 0; i < tokenNames.length; i++) {
			tokenNames[i] = VOCABULARY.getLiteralName(i);
			if (tokenNames[i] == null) {
				tokenNames[i] = VOCABULARY.getSymbolicName(i);
			}

			if (tokenNames[i] == null) {
				tokenNames[i] = "<INVALID>";
			}
		}
	}

	@Override
	@Deprecated
	public String[] getTokenNames() {
		return tokenNames;
	}

	@Override

	public Vocabulary getVocabulary() {
		return VOCABULARY;
	}

	@Override
	public String getGrammarFileName() { return "CompilatorLFC.g4"; }

	@Override
	public String[] getRuleNames() { return ruleNames; }

	@Override
	public String getSerializedATN() { return _serializedATN; }

	@Override
	public ATN getATN() { return _ATN; }

	public CompilatorLFCParser(TokenStream input) {
		super(input);
		_interp = new ParserATNSimulator(this,_ATN,_decisionToDFA,_sharedContextCache);
	}

	@SuppressWarnings("CheckReturnValue")
	public static class ProgramContext extends ParserRuleContext {
		public Main_functionContext main_function() {
			return getRuleContext(Main_functionContext.class,0);
		}
		public TerminalNode EOF() { return getToken(CompilatorLFCParser.EOF, 0); }
		public List<Global_declContext> global_decl() {
			return getRuleContexts(Global_declContext.class);
		}
		public Global_declContext global_decl(int i) {
			return getRuleContext(Global_declContext.class,i);
		}
		public ProgramContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_program; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof CompilatorLFCListener ) ((CompilatorLFCListener)listener).enterProgram(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof CompilatorLFCListener ) ((CompilatorLFCListener)listener).exitProgram(this);
		}
	}

	public final ProgramContext program() throws RecognitionException {
		ProgramContext _localctx = new ProgramContext(_ctx, getState());
		enterRule(_localctx, 0, RULE_program);
		try {
			int _alt;
			enterOuterAlt(_localctx, 1);
			{
			setState(59);
			_errHandler.sync(this);
			_alt = getInterpreter().adaptivePredict(_input,0,_ctx);
			while ( _alt!=2 && _alt!=org.antlr.v4.runtime.atn.ATN.INVALID_ALT_NUMBER ) {
				if ( _alt==1 ) {
					{
					{
					setState(56);
					global_decl();
					}
					} 
				}
				setState(61);
				_errHandler.sync(this);
				_alt = getInterpreter().adaptivePredict(_input,0,_ctx);
			}
			setState(62);
			main_function();
			setState(63);
			match(EOF);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class Global_declContext extends ParserRuleContext {
		public Var_declContext var_decl() {
			return getRuleContext(Var_declContext.class,0);
		}
		public TerminalNode SEMI() { return getToken(CompilatorLFCParser.SEMI, 0); }
		public FunctionContext function() {
			return getRuleContext(FunctionContext.class,0);
		}
		public Global_declContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_global_decl; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof CompilatorLFCListener ) ((CompilatorLFCListener)listener).enterGlobal_decl(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof CompilatorLFCListener ) ((CompilatorLFCListener)listener).exitGlobal_decl(this);
		}
	}

	public final Global_declContext global_decl() throws RecognitionException {
		Global_declContext _localctx = new Global_declContext(_ctx, getState());
		enterRule(_localctx, 2, RULE_global_decl);
		try {
			setState(69);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,1,_ctx) ) {
			case 1:
				enterOuterAlt(_localctx, 1);
				{
				setState(65);
				var_decl();
				setState(66);
				match(SEMI);
				}
				break;
			case 2:
				enterOuterAlt(_localctx, 2);
				{
				setState(68);
				function();
				}
				break;
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class Main_functionContext extends ParserRuleContext {
		public TerminalNode INT() { return getToken(CompilatorLFCParser.INT, 0); }
		public TerminalNode MAIN() { return getToken(CompilatorLFCParser.MAIN, 0); }
		public TerminalNode OPEN_PARAM() { return getToken(CompilatorLFCParser.OPEN_PARAM, 0); }
		public TerminalNode CLOSE_PARAM() { return getToken(CompilatorLFCParser.CLOSE_PARAM, 0); }
		public BlockContext block() {
			return getRuleContext(BlockContext.class,0);
		}
		public Main_functionContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_main_function; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof CompilatorLFCListener ) ((CompilatorLFCListener)listener).enterMain_function(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof CompilatorLFCListener ) ((CompilatorLFCListener)listener).exitMain_function(this);
		}
	}

	public final Main_functionContext main_function() throws RecognitionException {
		Main_functionContext _localctx = new Main_functionContext(_ctx, getState());
		enterRule(_localctx, 4, RULE_main_function);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(71);
			match(INT);
			setState(72);
			match(MAIN);
			setState(73);
			match(OPEN_PARAM);
			setState(74);
			match(CLOSE_PARAM);
			setState(75);
			block();
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class FunctionContext extends ParserRuleContext {
		public Func_declContext func_decl() {
			return getRuleContext(Func_declContext.class,0);
		}
		public BlockContext block() {
			return getRuleContext(BlockContext.class,0);
		}
		public FunctionContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_function; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof CompilatorLFCListener ) ((CompilatorLFCListener)listener).enterFunction(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof CompilatorLFCListener ) ((CompilatorLFCListener)listener).exitFunction(this);
		}
	}

	public final FunctionContext function() throws RecognitionException {
		FunctionContext _localctx = new FunctionContext(_ctx, getState());
		enterRule(_localctx, 6, RULE_function);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(77);
			func_decl();
			setState(78);
			block();
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class Func_declContext extends ParserRuleContext {
		public Func_typeContext func_type() {
			return getRuleContext(Func_typeContext.class,0);
		}
		public TerminalNode ID() { return getToken(CompilatorLFCParser.ID, 0); }
		public TerminalNode OPEN_PARAM() { return getToken(CompilatorLFCParser.OPEN_PARAM, 0); }
		public TerminalNode CLOSE_PARAM() { return getToken(CompilatorLFCParser.CLOSE_PARAM, 0); }
		public TerminalNode CONST() { return getToken(CompilatorLFCParser.CONST, 0); }
		public Param_listContext param_list() {
			return getRuleContext(Param_listContext.class,0);
		}
		public Func_declContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_func_decl; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof CompilatorLFCListener ) ((CompilatorLFCListener)listener).enterFunc_decl(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof CompilatorLFCListener ) ((CompilatorLFCListener)listener).exitFunc_decl(this);
		}
	}

	public final Func_declContext func_decl() throws RecognitionException {
		Func_declContext _localctx = new Func_declContext(_ctx, getState());
		enterRule(_localctx, 8, RULE_func_decl);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(81);
			_errHandler.sync(this);
			_la = _input.LA(1);
			if (_la==CONST) {
				{
				setState(80);
				match(CONST);
				}
			}

			setState(83);
			func_type();
			setState(84);
			match(ID);
			setState(85);
			match(OPEN_PARAM);
			setState(87);
			_errHandler.sync(this);
			_la = _input.LA(1);
			if ((((_la) & ~0x3f) == 0 && ((1L << _la) & 30L) != 0)) {
				{
				setState(86);
				param_list();
				}
			}

			setState(89);
			match(CLOSE_PARAM);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class Func_typeContext extends ParserRuleContext {
		public TerminalNode VOID() { return getToken(CompilatorLFCParser.VOID, 0); }
		public Var_typeContext var_type() {
			return getRuleContext(Var_typeContext.class,0);
		}
		public Func_typeContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_func_type; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof CompilatorLFCListener ) ((CompilatorLFCListener)listener).enterFunc_type(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof CompilatorLFCListener ) ((CompilatorLFCListener)listener).exitFunc_type(this);
		}
	}

	public final Func_typeContext func_type() throws RecognitionException {
		Func_typeContext _localctx = new Func_typeContext(_ctx, getState());
		enterRule(_localctx, 10, RULE_func_type);
		try {
			setState(93);
			_errHandler.sync(this);
			switch (_input.LA(1)) {
			case VOID:
				enterOuterAlt(_localctx, 1);
				{
				setState(91);
				match(VOID);
				}
				break;
			case INT:
			case FLOAT:
			case DOUBLE:
			case STRING:
				enterOuterAlt(_localctx, 2);
				{
				setState(92);
				var_type();
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class Param_listContext extends ParserRuleContext {
		public List<ParamContext> param() {
			return getRuleContexts(ParamContext.class);
		}
		public ParamContext param(int i) {
			return getRuleContext(ParamContext.class,i);
		}
		public List<TerminalNode> COMMA() { return getTokens(CompilatorLFCParser.COMMA); }
		public TerminalNode COMMA(int i) {
			return getToken(CompilatorLFCParser.COMMA, i);
		}
		public Param_listContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_param_list; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof CompilatorLFCListener ) ((CompilatorLFCListener)listener).enterParam_list(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof CompilatorLFCListener ) ((CompilatorLFCListener)listener).exitParam_list(this);
		}
	}

	public final Param_listContext param_list() throws RecognitionException {
		Param_listContext _localctx = new Param_listContext(_ctx, getState());
		enterRule(_localctx, 12, RULE_param_list);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(95);
			param();
			setState(100);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (_la==COMMA) {
				{
				{
				setState(96);
				match(COMMA);
				setState(97);
				param();
				}
				}
				setState(102);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class ParamContext extends ParserRuleContext {
		public Var_typeContext var_type() {
			return getRuleContext(Var_typeContext.class,0);
		}
		public TerminalNode ID() { return getToken(CompilatorLFCParser.ID, 0); }
		public ParamContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_param; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof CompilatorLFCListener ) ((CompilatorLFCListener)listener).enterParam(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof CompilatorLFCListener ) ((CompilatorLFCListener)listener).exitParam(this);
		}
	}

	public final ParamContext param() throws RecognitionException {
		ParamContext _localctx = new ParamContext(_ctx, getState());
		enterRule(_localctx, 14, RULE_param);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(103);
			var_type();
			setState(104);
			match(ID);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class BlockContext extends ParserRuleContext {
		public TerminalNode CURLY_OPEN_BRACKET() { return getToken(CompilatorLFCParser.CURLY_OPEN_BRACKET, 0); }
		public TerminalNode CURLY_CLOSE_BRACKET() { return getToken(CompilatorLFCParser.CURLY_CLOSE_BRACKET, 0); }
		public List<StatementContext> statement() {
			return getRuleContexts(StatementContext.class);
		}
		public StatementContext statement(int i) {
			return getRuleContext(StatementContext.class,i);
		}
		public BlockContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_block; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof CompilatorLFCListener ) ((CompilatorLFCListener)listener).enterBlock(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof CompilatorLFCListener ) ((CompilatorLFCListener)listener).exitBlock(this);
		}
	}

	public final BlockContext block() throws RecognitionException {
		BlockContext _localctx = new BlockContext(_ctx, getState());
		enterRule(_localctx, 16, RULE_block);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(106);
			match(CURLY_OPEN_BRACKET);
			setState(110);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while ((((_la) & ~0x3f) == 0 && ((1L << _la) & 51763349556926L) != 0)) {
				{
				{
				setState(107);
				statement();
				}
				}
				setState(112);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			setState(113);
			match(CURLY_CLOSE_BRACKET);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class StatementContext extends ParserRuleContext {
		public Var_declContext var_decl() {
			return getRuleContext(Var_declContext.class,0);
		}
		public TerminalNode SEMI() { return getToken(CompilatorLFCParser.SEMI, 0); }
		public Assignment_statementContext assignment_statement() {
			return getRuleContext(Assignment_statementContext.class,0);
		}
		public ExprContext expr() {
			return getRuleContext(ExprContext.class,0);
		}
		public If_statementContext if_statement() {
			return getRuleContext(If_statementContext.class,0);
		}
		public Return_statementContext return_statement() {
			return getRuleContext(Return_statementContext.class,0);
		}
		public While_statementContext while_statement() {
			return getRuleContext(While_statementContext.class,0);
		}
		public For_statementContext for_statement() {
			return getRuleContext(For_statementContext.class,0);
		}
		public Function_callContext function_call() {
			return getRuleContext(Function_callContext.class,0);
		}
		public BlockContext block() {
			return getRuleContext(BlockContext.class,0);
		}
		public StatementContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_statement; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof CompilatorLFCListener ) ((CompilatorLFCListener)listener).enterStatement(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof CompilatorLFCListener ) ((CompilatorLFCListener)listener).exitStatement(this);
		}
	}

	public final StatementContext statement() throws RecognitionException {
		StatementContext _localctx = new StatementContext(_ctx, getState());
		enterRule(_localctx, 18, RULE_statement);
		try {
			setState(128);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,7,_ctx) ) {
			case 1:
				enterOuterAlt(_localctx, 1);
				{
				setState(115);
				var_decl();
				setState(116);
				match(SEMI);
				}
				break;
			case 2:
				enterOuterAlt(_localctx, 2);
				{
				setState(118);
				assignment_statement();
				}
				break;
			case 3:
				enterOuterAlt(_localctx, 3);
				{
				setState(119);
				expr(0);
				setState(120);
				match(SEMI);
				}
				break;
			case 4:
				enterOuterAlt(_localctx, 4);
				{
				setState(122);
				if_statement();
				}
				break;
			case 5:
				enterOuterAlt(_localctx, 5);
				{
				setState(123);
				return_statement();
				}
				break;
			case 6:
				enterOuterAlt(_localctx, 6);
				{
				setState(124);
				while_statement();
				}
				break;
			case 7:
				enterOuterAlt(_localctx, 7);
				{
				setState(125);
				for_statement();
				}
				break;
			case 8:
				enterOuterAlt(_localctx, 8);
				{
				setState(126);
				function_call();
				}
				break;
			case 9:
				enterOuterAlt(_localctx, 9);
				{
				setState(127);
				block();
				}
				break;
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class Var_declContext extends ParserRuleContext {
		public Var_typeContext var_type() {
			return getRuleContext(Var_typeContext.class,0);
		}
		public TerminalNode ID() { return getToken(CompilatorLFCParser.ID, 0); }
		public TerminalNode CONST() { return getToken(CompilatorLFCParser.CONST, 0); }
		public TerminalNode ASSIGN() { return getToken(CompilatorLFCParser.ASSIGN, 0); }
		public ExprContext expr() {
			return getRuleContext(ExprContext.class,0);
		}
		public Var_declContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_var_decl; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof CompilatorLFCListener ) ((CompilatorLFCListener)listener).enterVar_decl(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof CompilatorLFCListener ) ((CompilatorLFCListener)listener).exitVar_decl(this);
		}
	}

	public final Var_declContext var_decl() throws RecognitionException {
		Var_declContext _localctx = new Var_declContext(_ctx, getState());
		enterRule(_localctx, 20, RULE_var_decl);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(131);
			_errHandler.sync(this);
			_la = _input.LA(1);
			if (_la==CONST) {
				{
				setState(130);
				match(CONST);
				}
			}

			setState(133);
			var_type();
			setState(134);
			match(ID);
			setState(137);
			_errHandler.sync(this);
			_la = _input.LA(1);
			if (_la==ASSIGN) {
				{
				setState(135);
				match(ASSIGN);
				setState(136);
				expr(0);
				}
			}

			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class Var_typeContext extends ParserRuleContext {
		public TerminalNode INT() { return getToken(CompilatorLFCParser.INT, 0); }
		public TerminalNode FLOAT() { return getToken(CompilatorLFCParser.FLOAT, 0); }
		public TerminalNode DOUBLE() { return getToken(CompilatorLFCParser.DOUBLE, 0); }
		public TerminalNode STRING() { return getToken(CompilatorLFCParser.STRING, 0); }
		public Var_typeContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_var_type; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof CompilatorLFCListener ) ((CompilatorLFCListener)listener).enterVar_type(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof CompilatorLFCListener ) ((CompilatorLFCListener)listener).exitVar_type(this);
		}
	}

	public final Var_typeContext var_type() throws RecognitionException {
		Var_typeContext _localctx = new Var_typeContext(_ctx, getState());
		enterRule(_localctx, 22, RULE_var_type);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(139);
			_la = _input.LA(1);
			if ( !((((_la) & ~0x3f) == 0 && ((1L << _la) & 30L) != 0)) ) {
			_errHandler.recoverInline(this);
			}
			else {
				if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
				_errHandler.reportMatch(this);
				consume();
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class Return_statementContext extends ParserRuleContext {
		public TerminalNode RETURN() { return getToken(CompilatorLFCParser.RETURN, 0); }
		public TerminalNode SEMI() { return getToken(CompilatorLFCParser.SEMI, 0); }
		public ExprContext expr() {
			return getRuleContext(ExprContext.class,0);
		}
		public Return_statementContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_return_statement; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof CompilatorLFCListener ) ((CompilatorLFCListener)listener).enterReturn_statement(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof CompilatorLFCListener ) ((CompilatorLFCListener)listener).exitReturn_statement(this);
		}
	}

	public final Return_statementContext return_statement() throws RecognitionException {
		Return_statementContext _localctx = new Return_statementContext(_ctx, getState());
		enterRule(_localctx, 24, RULE_return_statement);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(141);
			match(RETURN);
			setState(143);
			_errHandler.sync(this);
			_la = _input.LA(1);
			if ((((_la) & ~0x3f) == 0 && ((1L << _la) & 51694630076416L) != 0)) {
				{
				setState(142);
				expr(0);
				}
			}

			setState(145);
			match(SEMI);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class If_statementContext extends ParserRuleContext {
		public TerminalNode IF() { return getToken(CompilatorLFCParser.IF, 0); }
		public TerminalNode OPEN_PARAM() { return getToken(CompilatorLFCParser.OPEN_PARAM, 0); }
		public List<ConditionContext> condition() {
			return getRuleContexts(ConditionContext.class);
		}
		public ConditionContext condition(int i) {
			return getRuleContext(ConditionContext.class,i);
		}
		public TerminalNode CLOSE_PARAM() { return getToken(CompilatorLFCParser.CLOSE_PARAM, 0); }
		public List<StatementContext> statement() {
			return getRuleContexts(StatementContext.class);
		}
		public StatementContext statement(int i) {
			return getRuleContext(StatementContext.class,i);
		}
		public List<TerminalNode> NOT() { return getTokens(CompilatorLFCParser.NOT); }
		public TerminalNode NOT(int i) {
			return getToken(CompilatorLFCParser.NOT, i);
		}
		public List<Logical_opContext> logical_op() {
			return getRuleContexts(Logical_opContext.class);
		}
		public Logical_opContext logical_op(int i) {
			return getRuleContext(Logical_opContext.class,i);
		}
		public TerminalNode ELSE() { return getToken(CompilatorLFCParser.ELSE, 0); }
		public If_statementContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_if_statement; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof CompilatorLFCListener ) ((CompilatorLFCListener)listener).enterIf_statement(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof CompilatorLFCListener ) ((CompilatorLFCListener)listener).exitIf_statement(this);
		}
	}

	public final If_statementContext if_statement() throws RecognitionException {
		If_statementContext _localctx = new If_statementContext(_ctx, getState());
		enterRule(_localctx, 26, RULE_if_statement);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(147);
			match(IF);
			setState(148);
			match(OPEN_PARAM);
			setState(150);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,11,_ctx) ) {
			case 1:
				{
				setState(149);
				match(NOT);
				}
				break;
			}
			setState(152);
			condition();
			setState(161);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (_la==AND || _la==OR) {
				{
				{
				setState(153);
				logical_op();
				setState(155);
				_errHandler.sync(this);
				switch ( getInterpreter().adaptivePredict(_input,12,_ctx) ) {
				case 1:
					{
					setState(154);
					match(NOT);
					}
					break;
				}
				setState(157);
				condition();
				}
				}
				setState(163);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			setState(164);
			match(CLOSE_PARAM);
			setState(165);
			statement();
			setState(168);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,14,_ctx) ) {
			case 1:
				{
				setState(166);
				match(ELSE);
				setState(167);
				statement();
				}
				break;
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class ConditionContext extends ParserRuleContext {
		public List<ExprContext> expr() {
			return getRuleContexts(ExprContext.class);
		}
		public ExprContext expr(int i) {
			return getRuleContext(ExprContext.class,i);
		}
		public Relational_opContext relational_op() {
			return getRuleContext(Relational_opContext.class,0);
		}
		public ConditionContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_condition; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof CompilatorLFCListener ) ((CompilatorLFCListener)listener).enterCondition(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof CompilatorLFCListener ) ((CompilatorLFCListener)listener).exitCondition(this);
		}
	}

	public final ConditionContext condition() throws RecognitionException {
		ConditionContext _localctx = new ConditionContext(_ctx, getState());
		enterRule(_localctx, 28, RULE_condition);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(170);
			expr(0);
			setState(171);
			relational_op();
			setState(172);
			expr(0);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class Relational_opContext extends ParserRuleContext {
		public TerminalNode LESS_THAN() { return getToken(CompilatorLFCParser.LESS_THAN, 0); }
		public TerminalNode GREATER_THAN() { return getToken(CompilatorLFCParser.GREATER_THAN, 0); }
		public TerminalNode LESS_OR_EQUAL() { return getToken(CompilatorLFCParser.LESS_OR_EQUAL, 0); }
		public TerminalNode GREATER_OR_EQUAL() { return getToken(CompilatorLFCParser.GREATER_OR_EQUAL, 0); }
		public TerminalNode EQUAL() { return getToken(CompilatorLFCParser.EQUAL, 0); }
		public TerminalNode NOT_EQUAL() { return getToken(CompilatorLFCParser.NOT_EQUAL, 0); }
		public Relational_opContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_relational_op; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof CompilatorLFCListener ) ((CompilatorLFCListener)listener).enterRelational_op(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof CompilatorLFCListener ) ((CompilatorLFCListener)listener).exitRelational_op(this);
		}
	}

	public final Relational_opContext relational_op() throws RecognitionException {
		Relational_opContext _localctx = new Relational_opContext(_ctx, getState());
		enterRule(_localctx, 30, RULE_relational_op);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(174);
			_la = _input.LA(1);
			if ( !((((_la) & ~0x3f) == 0 && ((1L << _la) & 258048L) != 0)) ) {
			_errHandler.recoverInline(this);
			}
			else {
				if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
				_errHandler.reportMatch(this);
				consume();
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class Logical_opContext extends ParserRuleContext {
		public TerminalNode AND() { return getToken(CompilatorLFCParser.AND, 0); }
		public TerminalNode OR() { return getToken(CompilatorLFCParser.OR, 0); }
		public Logical_opContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_logical_op; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof CompilatorLFCListener ) ((CompilatorLFCListener)listener).enterLogical_op(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof CompilatorLFCListener ) ((CompilatorLFCListener)listener).exitLogical_op(this);
		}
	}

	public final Logical_opContext logical_op() throws RecognitionException {
		Logical_opContext _localctx = new Logical_opContext(_ctx, getState());
		enterRule(_localctx, 32, RULE_logical_op);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(176);
			_la = _input.LA(1);
			if ( !(_la==AND || _la==OR) ) {
			_errHandler.recoverInline(this);
			}
			else {
				if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
				_errHandler.reportMatch(this);
				consume();
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class Assign_opContext extends ParserRuleContext {
		public TerminalNode ASSIGN() { return getToken(CompilatorLFCParser.ASSIGN, 0); }
		public TerminalNode ADD_ASSIGN() { return getToken(CompilatorLFCParser.ADD_ASSIGN, 0); }
		public TerminalNode SUB_ASSIGN() { return getToken(CompilatorLFCParser.SUB_ASSIGN, 0); }
		public TerminalNode MUL_ASSIGN() { return getToken(CompilatorLFCParser.MUL_ASSIGN, 0); }
		public TerminalNode DIV_ASSIGN() { return getToken(CompilatorLFCParser.DIV_ASSIGN, 0); }
		public TerminalNode MOD_ASSIGN() { return getToken(CompilatorLFCParser.MOD_ASSIGN, 0); }
		public Assign_opContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_assign_op; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof CompilatorLFCListener ) ((CompilatorLFCListener)listener).enterAssign_op(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof CompilatorLFCListener ) ((CompilatorLFCListener)listener).exitAssign_op(this);
		}
	}

	public final Assign_opContext assign_op() throws RecognitionException {
		Assign_opContext _localctx = new Assign_opContext(_ctx, getState());
		enterRule(_localctx, 34, RULE_assign_op);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(178);
			_la = _input.LA(1);
			if ( !((((_la) & ~0x3f) == 0 && ((1L << _la) & 132120576L) != 0)) ) {
			_errHandler.recoverInline(this);
			}
			else {
				if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
				_errHandler.reportMatch(this);
				consume();
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class Assignment_statementContext extends ParserRuleContext {
		public TerminalNode ID() { return getToken(CompilatorLFCParser.ID, 0); }
		public Assign_opContext assign_op() {
			return getRuleContext(Assign_opContext.class,0);
		}
		public ExprContext expr() {
			return getRuleContext(ExprContext.class,0);
		}
		public TerminalNode SEMI() { return getToken(CompilatorLFCParser.SEMI, 0); }
		public Assignment_statementContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_assignment_statement; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof CompilatorLFCListener ) ((CompilatorLFCListener)listener).enterAssignment_statement(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof CompilatorLFCListener ) ((CompilatorLFCListener)listener).exitAssignment_statement(this);
		}
	}

	public final Assignment_statementContext assignment_statement() throws RecognitionException {
		Assignment_statementContext _localctx = new Assignment_statementContext(_ctx, getState());
		enterRule(_localctx, 36, RULE_assignment_statement);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(180);
			match(ID);
			setState(181);
			assign_op();
			setState(182);
			expr(0);
			setState(183);
			match(SEMI);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class While_statementContext extends ParserRuleContext {
		public TerminalNode WHILE() { return getToken(CompilatorLFCParser.WHILE, 0); }
		public TerminalNode OPEN_PARAM() { return getToken(CompilatorLFCParser.OPEN_PARAM, 0); }
		public List<ConditionContext> condition() {
			return getRuleContexts(ConditionContext.class);
		}
		public ConditionContext condition(int i) {
			return getRuleContext(ConditionContext.class,i);
		}
		public TerminalNode CLOSE_PARAM() { return getToken(CompilatorLFCParser.CLOSE_PARAM, 0); }
		public StatementContext statement() {
			return getRuleContext(StatementContext.class,0);
		}
		public List<TerminalNode> NOT() { return getTokens(CompilatorLFCParser.NOT); }
		public TerminalNode NOT(int i) {
			return getToken(CompilatorLFCParser.NOT, i);
		}
		public List<Logical_opContext> logical_op() {
			return getRuleContexts(Logical_opContext.class);
		}
		public Logical_opContext logical_op(int i) {
			return getRuleContext(Logical_opContext.class,i);
		}
		public While_statementContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_while_statement; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof CompilatorLFCListener ) ((CompilatorLFCListener)listener).enterWhile_statement(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof CompilatorLFCListener ) ((CompilatorLFCListener)listener).exitWhile_statement(this);
		}
	}

	public final While_statementContext while_statement() throws RecognitionException {
		While_statementContext _localctx = new While_statementContext(_ctx, getState());
		enterRule(_localctx, 38, RULE_while_statement);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(185);
			match(WHILE);
			setState(186);
			match(OPEN_PARAM);
			setState(188);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,15,_ctx) ) {
			case 1:
				{
				setState(187);
				match(NOT);
				}
				break;
			}
			setState(190);
			condition();
			setState(199);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (_la==AND || _la==OR) {
				{
				{
				setState(191);
				logical_op();
				setState(193);
				_errHandler.sync(this);
				switch ( getInterpreter().adaptivePredict(_input,16,_ctx) ) {
				case 1:
					{
					setState(192);
					match(NOT);
					}
					break;
				}
				setState(195);
				condition();
				}
				}
				setState(201);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			setState(202);
			match(CLOSE_PARAM);
			setState(203);
			statement();
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class For_statementContext extends ParserRuleContext {
		public TerminalNode FOR() { return getToken(CompilatorLFCParser.FOR, 0); }
		public TerminalNode OPEN_PARAM() { return getToken(CompilatorLFCParser.OPEN_PARAM, 0); }
		public List<TerminalNode> SEMI() { return getTokens(CompilatorLFCParser.SEMI); }
		public TerminalNode SEMI(int i) {
			return getToken(CompilatorLFCParser.SEMI, i);
		}
		public TerminalNode CLOSE_PARAM() { return getToken(CompilatorLFCParser.CLOSE_PARAM, 0); }
		public StatementContext statement() {
			return getRuleContext(StatementContext.class,0);
		}
		public For_initContext for_init() {
			return getRuleContext(For_initContext.class,0);
		}
		public For_conditionContext for_condition() {
			return getRuleContext(For_conditionContext.class,0);
		}
		public For_stepContext for_step() {
			return getRuleContext(For_stepContext.class,0);
		}
		public For_statementContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_for_statement; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof CompilatorLFCListener ) ((CompilatorLFCListener)listener).enterFor_statement(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof CompilatorLFCListener ) ((CompilatorLFCListener)listener).exitFor_statement(this);
		}
	}

	public final For_statementContext for_statement() throws RecognitionException {
		For_statementContext _localctx = new For_statementContext(_ctx, getState());
		enterRule(_localctx, 40, RULE_for_statement);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(205);
			match(FOR);
			setState(206);
			match(OPEN_PARAM);
			setState(208);
			_errHandler.sync(this);
			_la = _input.LA(1);
			if ((((_la) & ~0x3f) == 0 && ((1L << _la) & 35184372088894L) != 0)) {
				{
				setState(207);
				for_init();
				}
			}

			setState(210);
			match(SEMI);
			setState(212);
			_errHandler.sync(this);
			_la = _input.LA(1);
			if ((((_la) & ~0x3f) == 0 && ((1L << _la) & 51694630076416L) != 0)) {
				{
				setState(211);
				for_condition();
				}
			}

			setState(214);
			match(SEMI);
			setState(216);
			_errHandler.sync(this);
			_la = _input.LA(1);
			if ((((_la) & ~0x3f) == 0 && ((1L << _la) & 51694630076416L) != 0)) {
				{
				setState(215);
				for_step();
				}
			}

			setState(218);
			match(CLOSE_PARAM);
			setState(219);
			statement();
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class For_initContext extends ParserRuleContext {
		public Var_declContext var_decl() {
			return getRuleContext(Var_declContext.class,0);
		}
		public Assignment_statement_no_semiContext assignment_statement_no_semi() {
			return getRuleContext(Assignment_statement_no_semiContext.class,0);
		}
		public For_initContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_for_init; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof CompilatorLFCListener ) ((CompilatorLFCListener)listener).enterFor_init(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof CompilatorLFCListener ) ((CompilatorLFCListener)listener).exitFor_init(this);
		}
	}

	public final For_initContext for_init() throws RecognitionException {
		For_initContext _localctx = new For_initContext(_ctx, getState());
		enterRule(_localctx, 42, RULE_for_init);
		try {
			setState(223);
			_errHandler.sync(this);
			switch (_input.LA(1)) {
			case INT:
			case FLOAT:
			case DOUBLE:
			case STRING:
			case CONST:
				enterOuterAlt(_localctx, 1);
				{
				setState(221);
				var_decl();
				}
				break;
			case ID:
				enterOuterAlt(_localctx, 2);
				{
				setState(222);
				assignment_statement_no_semi();
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class For_conditionContext extends ParserRuleContext {
		public List<ConditionContext> condition() {
			return getRuleContexts(ConditionContext.class);
		}
		public ConditionContext condition(int i) {
			return getRuleContext(ConditionContext.class,i);
		}
		public List<TerminalNode> NOT() { return getTokens(CompilatorLFCParser.NOT); }
		public TerminalNode NOT(int i) {
			return getToken(CompilatorLFCParser.NOT, i);
		}
		public Logical_opContext logical_op() {
			return getRuleContext(Logical_opContext.class,0);
		}
		public For_conditionContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_for_condition; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof CompilatorLFCListener ) ((CompilatorLFCListener)listener).enterFor_condition(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof CompilatorLFCListener ) ((CompilatorLFCListener)listener).exitFor_condition(this);
		}
	}

	public final For_conditionContext for_condition() throws RecognitionException {
		For_conditionContext _localctx = new For_conditionContext(_ctx, getState());
		enterRule(_localctx, 44, RULE_for_condition);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(226);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,22,_ctx) ) {
			case 1:
				{
				setState(225);
				match(NOT);
				}
				break;
			}
			setState(228);
			condition();
			setState(235);
			_errHandler.sync(this);
			_la = _input.LA(1);
			if (_la==AND || _la==OR) {
				{
				setState(229);
				logical_op();
				setState(231);
				_errHandler.sync(this);
				switch ( getInterpreter().adaptivePredict(_input,23,_ctx) ) {
				case 1:
					{
					setState(230);
					match(NOT);
					}
					break;
				}
				setState(233);
				condition();
				}
			}

			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class For_stepContext extends ParserRuleContext {
		public Assignment_statement_no_semiContext assignment_statement_no_semi() {
			return getRuleContext(Assignment_statement_no_semiContext.class,0);
		}
		public ExprContext expr() {
			return getRuleContext(ExprContext.class,0);
		}
		public For_stepContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_for_step; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof CompilatorLFCListener ) ((CompilatorLFCListener)listener).enterFor_step(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof CompilatorLFCListener ) ((CompilatorLFCListener)listener).exitFor_step(this);
		}
	}

	public final For_stepContext for_step() throws RecognitionException {
		For_stepContext _localctx = new For_stepContext(_ctx, getState());
		enterRule(_localctx, 46, RULE_for_step);
		try {
			setState(239);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,25,_ctx) ) {
			case 1:
				enterOuterAlt(_localctx, 1);
				{
				setState(237);
				assignment_statement_no_semi();
				}
				break;
			case 2:
				enterOuterAlt(_localctx, 2);
				{
				setState(238);
				expr(0);
				}
				break;
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class Assignment_statement_no_semiContext extends ParserRuleContext {
		public TerminalNode ID() { return getToken(CompilatorLFCParser.ID, 0); }
		public Assign_opContext assign_op() {
			return getRuleContext(Assign_opContext.class,0);
		}
		public ExprContext expr() {
			return getRuleContext(ExprContext.class,0);
		}
		public Assignment_statement_no_semiContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_assignment_statement_no_semi; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof CompilatorLFCListener ) ((CompilatorLFCListener)listener).enterAssignment_statement_no_semi(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof CompilatorLFCListener ) ((CompilatorLFCListener)listener).exitAssignment_statement_no_semi(this);
		}
	}

	public final Assignment_statement_no_semiContext assignment_statement_no_semi() throws RecognitionException {
		Assignment_statement_no_semiContext _localctx = new Assignment_statement_no_semiContext(_ctx, getState());
		enterRule(_localctx, 48, RULE_assignment_statement_no_semi);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(241);
			match(ID);
			setState(242);
			assign_op();
			setState(243);
			expr(0);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class ExprContext extends ParserRuleContext {
		public ExprContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_expr; }
	 
		public ExprContext() { }
		public void copyFrom(ExprContext ctx) {
			super.copyFrom(ctx);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class DoubleLiteralExpContext extends ExprContext {
		public TerminalNode DOUBLE_LITERAL() { return getToken(CompilatorLFCParser.DOUBLE_LITERAL, 0); }
		public DoubleLiteralExpContext(ExprContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof CompilatorLFCListener ) ((CompilatorLFCListener)listener).enterDoubleLiteralExp(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof CompilatorLFCListener ) ((CompilatorLFCListener)listener).exitDoubleLiteralExp(this);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class StringLiteralExpContext extends ExprContext {
		public TerminalNode STRING_LITERAL() { return getToken(CompilatorLFCParser.STRING_LITERAL, 0); }
		public StringLiteralExpContext(ExprContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof CompilatorLFCListener ) ((CompilatorLFCListener)listener).enterStringLiteralExp(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof CompilatorLFCListener ) ((CompilatorLFCListener)listener).exitStringLiteralExp(this);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class EqualityExpContext extends ExprContext {
		public List<ExprContext> expr() {
			return getRuleContexts(ExprContext.class);
		}
		public ExprContext expr(int i) {
			return getRuleContext(ExprContext.class,i);
		}
		public TerminalNode EQUAL() { return getToken(CompilatorLFCParser.EQUAL, 0); }
		public TerminalNode NOT_EQUAL() { return getToken(CompilatorLFCParser.NOT_EQUAL, 0); }
		public EqualityExpContext(ExprContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof CompilatorLFCListener ) ((CompilatorLFCListener)listener).enterEqualityExp(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof CompilatorLFCListener ) ((CompilatorLFCListener)listener).exitEqualityExp(this);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class FloatLiteralExpContext extends ExprContext {
		public TerminalNode FLOAT_LITERAL() { return getToken(CompilatorLFCParser.FLOAT_LITERAL, 0); }
		public FloatLiteralExpContext(ExprContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof CompilatorLFCListener ) ((CompilatorLFCListener)listener).enterFloatLiteralExp(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof CompilatorLFCListener ) ((CompilatorLFCListener)listener).exitFloatLiteralExp(this);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class PostIncExpContext extends ExprContext {
		public ExprContext expr() {
			return getRuleContext(ExprContext.class,0);
		}
		public TerminalNode INCREMENT() { return getToken(CompilatorLFCParser.INCREMENT, 0); }
		public PostIncExpContext(ExprContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof CompilatorLFCListener ) ((CompilatorLFCListener)listener).enterPostIncExp(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof CompilatorLFCListener ) ((CompilatorLFCListener)listener).exitPostIncExp(this);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class PreDecExpContext extends ExprContext {
		public TerminalNode DECREMENT() { return getToken(CompilatorLFCParser.DECREMENT, 0); }
		public ExprContext expr() {
			return getRuleContext(ExprContext.class,0);
		}
		public PreDecExpContext(ExprContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof CompilatorLFCListener ) ((CompilatorLFCListener)listener).enterPreDecExp(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof CompilatorLFCListener ) ((CompilatorLFCListener)listener).exitPreDecExp(this);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class FuncCallExpContext extends ExprContext {
		public Function_callContext function_call() {
			return getRuleContext(Function_callContext.class,0);
		}
		public FuncCallExpContext(ExprContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof CompilatorLFCListener ) ((CompilatorLFCListener)listener).enterFuncCallExp(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof CompilatorLFCListener ) ((CompilatorLFCListener)listener).exitFuncCallExp(this);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class NotExpContext extends ExprContext {
		public TerminalNode NOT() { return getToken(CompilatorLFCParser.NOT, 0); }
		public ExprContext expr() {
			return getRuleContext(ExprContext.class,0);
		}
		public NotExpContext(ExprContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof CompilatorLFCListener ) ((CompilatorLFCListener)listener).enterNotExp(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof CompilatorLFCListener ) ((CompilatorLFCListener)listener).exitNotExp(this);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class AddSubExpContext extends ExprContext {
		public List<ExprContext> expr() {
			return getRuleContexts(ExprContext.class);
		}
		public ExprContext expr(int i) {
			return getRuleContext(ExprContext.class,i);
		}
		public TerminalNode PLUS() { return getToken(CompilatorLFCParser.PLUS, 0); }
		public TerminalNode MINUS() { return getToken(CompilatorLFCParser.MINUS, 0); }
		public AddSubExpContext(ExprContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof CompilatorLFCListener ) ((CompilatorLFCListener)listener).enterAddSubExp(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof CompilatorLFCListener ) ((CompilatorLFCListener)listener).exitAddSubExp(this);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class IdExpContext extends ExprContext {
		public TerminalNode ID() { return getToken(CompilatorLFCParser.ID, 0); }
		public IdExpContext(ExprContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof CompilatorLFCListener ) ((CompilatorLFCListener)listener).enterIdExp(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof CompilatorLFCListener ) ((CompilatorLFCListener)listener).exitIdExp(this);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class MulDivModExpContext extends ExprContext {
		public List<ExprContext> expr() {
			return getRuleContexts(ExprContext.class);
		}
		public ExprContext expr(int i) {
			return getRuleContext(ExprContext.class,i);
		}
		public TerminalNode MUL() { return getToken(CompilatorLFCParser.MUL, 0); }
		public TerminalNode DIV() { return getToken(CompilatorLFCParser.DIV, 0); }
		public TerminalNode MOD() { return getToken(CompilatorLFCParser.MOD, 0); }
		public MulDivModExpContext(ExprContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof CompilatorLFCListener ) ((CompilatorLFCListener)listener).enterMulDivModExp(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof CompilatorLFCListener ) ((CompilatorLFCListener)listener).exitMulDivModExp(this);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class PostDecExpContext extends ExprContext {
		public ExprContext expr() {
			return getRuleContext(ExprContext.class,0);
		}
		public TerminalNode DECREMENT() { return getToken(CompilatorLFCParser.DECREMENT, 0); }
		public PostDecExpContext(ExprContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof CompilatorLFCListener ) ((CompilatorLFCListener)listener).enterPostDecExp(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof CompilatorLFCListener ) ((CompilatorLFCListener)listener).exitPostDecExp(this);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class ParenthesisExpContext extends ExprContext {
		public TerminalNode OPEN_PARAM() { return getToken(CompilatorLFCParser.OPEN_PARAM, 0); }
		public ExprContext expr() {
			return getRuleContext(ExprContext.class,0);
		}
		public TerminalNode CLOSE_PARAM() { return getToken(CompilatorLFCParser.CLOSE_PARAM, 0); }
		public ParenthesisExpContext(ExprContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof CompilatorLFCListener ) ((CompilatorLFCListener)listener).enterParenthesisExp(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof CompilatorLFCListener ) ((CompilatorLFCListener)listener).exitParenthesisExp(this);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class PreIncExpContext extends ExprContext {
		public TerminalNode INCREMENT() { return getToken(CompilatorLFCParser.INCREMENT, 0); }
		public ExprContext expr() {
			return getRuleContext(ExprContext.class,0);
		}
		public PreIncExpContext(ExprContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof CompilatorLFCListener ) ((CompilatorLFCListener)listener).enterPreIncExp(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof CompilatorLFCListener ) ((CompilatorLFCListener)listener).exitPreIncExp(this);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class RelationalExpContext extends ExprContext {
		public List<ExprContext> expr() {
			return getRuleContexts(ExprContext.class);
		}
		public ExprContext expr(int i) {
			return getRuleContext(ExprContext.class,i);
		}
		public TerminalNode LESS_THAN() { return getToken(CompilatorLFCParser.LESS_THAN, 0); }
		public TerminalNode LESS_OR_EQUAL() { return getToken(CompilatorLFCParser.LESS_OR_EQUAL, 0); }
		public TerminalNode GREATER_THAN() { return getToken(CompilatorLFCParser.GREATER_THAN, 0); }
		public TerminalNode GREATER_OR_EQUAL() { return getToken(CompilatorLFCParser.GREATER_OR_EQUAL, 0); }
		public RelationalExpContext(ExprContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof CompilatorLFCListener ) ((CompilatorLFCListener)listener).enterRelationalExp(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof CompilatorLFCListener ) ((CompilatorLFCListener)listener).exitRelationalExp(this);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class LogicalExpContext extends ExprContext {
		public List<ExprContext> expr() {
			return getRuleContexts(ExprContext.class);
		}
		public ExprContext expr(int i) {
			return getRuleContext(ExprContext.class,i);
		}
		public TerminalNode AND() { return getToken(CompilatorLFCParser.AND, 0); }
		public TerminalNode OR() { return getToken(CompilatorLFCParser.OR, 0); }
		public LogicalExpContext(ExprContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof CompilatorLFCListener ) ((CompilatorLFCListener)listener).enterLogicalExp(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof CompilatorLFCListener ) ((CompilatorLFCListener)listener).exitLogicalExp(this);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class IntLiteralExpContext extends ExprContext {
		public TerminalNode INT_LITERAL() { return getToken(CompilatorLFCParser.INT_LITERAL, 0); }
		public IntLiteralExpContext(ExprContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof CompilatorLFCListener ) ((CompilatorLFCListener)listener).enterIntLiteralExp(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof CompilatorLFCListener ) ((CompilatorLFCListener)listener).exitIntLiteralExp(this);
		}
	}

	public final ExprContext expr() throws RecognitionException {
		return expr(0);
	}

	private ExprContext expr(int _p) throws RecognitionException {
		ParserRuleContext _parentctx = _ctx;
		int _parentState = getState();
		ExprContext _localctx = new ExprContext(_ctx, _parentState);
		ExprContext _prevctx = _localctx;
		int _startState = 50;
		enterRecursionRule(_localctx, 50, RULE_expr, _p);
		int _la;
		try {
			int _alt;
			enterOuterAlt(_localctx, 1);
			{
			setState(262);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,26,_ctx) ) {
			case 1:
				{
				_localctx = new ParenthesisExpContext(_localctx);
				_ctx = _localctx;
				_prevctx = _localctx;

				setState(246);
				match(OPEN_PARAM);
				setState(247);
				expr(0);
				setState(248);
				match(CLOSE_PARAM);
				}
				break;
			case 2:
				{
				_localctx = new NotExpContext(_localctx);
				_ctx = _localctx;
				_prevctx = _localctx;
				setState(250);
				match(NOT);
				setState(251);
				expr(11);
				}
				break;
			case 3:
				{
				_localctx = new PreIncExpContext(_localctx);
				_ctx = _localctx;
				_prevctx = _localctx;
				setState(252);
				match(INCREMENT);
				setState(253);
				expr(9);
				}
				break;
			case 4:
				{
				_localctx = new PreDecExpContext(_localctx);
				_ctx = _localctx;
				_prevctx = _localctx;
				setState(254);
				match(DECREMENT);
				setState(255);
				expr(7);
				}
				break;
			case 5:
				{
				_localctx = new FuncCallExpContext(_localctx);
				_ctx = _localctx;
				_prevctx = _localctx;
				setState(256);
				function_call();
				}
				break;
			case 6:
				{
				_localctx = new IdExpContext(_localctx);
				_ctx = _localctx;
				_prevctx = _localctx;
				setState(257);
				match(ID);
				}
				break;
			case 7:
				{
				_localctx = new IntLiteralExpContext(_localctx);
				_ctx = _localctx;
				_prevctx = _localctx;
				setState(258);
				match(INT_LITERAL);
				}
				break;
			case 8:
				{
				_localctx = new FloatLiteralExpContext(_localctx);
				_ctx = _localctx;
				_prevctx = _localctx;
				setState(259);
				match(FLOAT_LITERAL);
				}
				break;
			case 9:
				{
				_localctx = new DoubleLiteralExpContext(_localctx);
				_ctx = _localctx;
				_prevctx = _localctx;
				setState(260);
				match(DOUBLE_LITERAL);
				}
				break;
			case 10:
				{
				_localctx = new StringLiteralExpContext(_localctx);
				_ctx = _localctx;
				_prevctx = _localctx;
				setState(261);
				match(STRING_LITERAL);
				}
				break;
			}
			_ctx.stop = _input.LT(-1);
			setState(285);
			_errHandler.sync(this);
			_alt = getInterpreter().adaptivePredict(_input,28,_ctx);
			while ( _alt!=2 && _alt!=org.antlr.v4.runtime.atn.ATN.INVALID_ALT_NUMBER ) {
				if ( _alt==1 ) {
					if ( _parseListeners!=null ) triggerExitRuleEvent();
					_prevctx = _localctx;
					{
					setState(283);
					_errHandler.sync(this);
					switch ( getInterpreter().adaptivePredict(_input,27,_ctx) ) {
					case 1:
						{
						_localctx = new MulDivModExpContext(new ExprContext(_parentctx, _parentState));
						pushNewRecursionContext(_localctx, _startState, RULE_expr);
						setState(264);
						if (!(precpred(_ctx, 16))) throw new FailedPredicateException(this, "precpred(_ctx, 16)");
						setState(265);
						_la = _input.LA(1);
						if ( !((((_la) & ~0x3f) == 0 && ((1L << _la) & 15032385536L) != 0)) ) {
						_errHandler.recoverInline(this);
						}
						else {
							if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
							_errHandler.reportMatch(this);
							consume();
						}
						setState(266);
						expr(17);
						}
						break;
					case 2:
						{
						_localctx = new AddSubExpContext(new ExprContext(_parentctx, _parentState));
						pushNewRecursionContext(_localctx, _startState, RULE_expr);
						setState(267);
						if (!(precpred(_ctx, 15))) throw new FailedPredicateException(this, "precpred(_ctx, 15)");
						setState(268);
						_la = _input.LA(1);
						if ( !(_la==PLUS || _la==MINUS) ) {
						_errHandler.recoverInline(this);
						}
						else {
							if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
							_errHandler.reportMatch(this);
							consume();
						}
						setState(269);
						expr(16);
						}
						break;
					case 3:
						{
						_localctx = new RelationalExpContext(new ExprContext(_parentctx, _parentState));
						pushNewRecursionContext(_localctx, _startState, RULE_expr);
						setState(270);
						if (!(precpred(_ctx, 14))) throw new FailedPredicateException(this, "precpred(_ctx, 14)");
						setState(271);
						_la = _input.LA(1);
						if ( !((((_la) & ~0x3f) == 0 && ((1L << _la) & 110592L) != 0)) ) {
						_errHandler.recoverInline(this);
						}
						else {
							if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
							_errHandler.reportMatch(this);
							consume();
						}
						setState(272);
						expr(15);
						}
						break;
					case 4:
						{
						_localctx = new EqualityExpContext(new ExprContext(_parentctx, _parentState));
						pushNewRecursionContext(_localctx, _startState, RULE_expr);
						setState(273);
						if (!(precpred(_ctx, 13))) throw new FailedPredicateException(this, "precpred(_ctx, 13)");
						setState(274);
						_la = _input.LA(1);
						if ( !(_la==EQUAL || _la==NOT_EQUAL) ) {
						_errHandler.recoverInline(this);
						}
						else {
							if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
							_errHandler.reportMatch(this);
							consume();
						}
						setState(275);
						expr(14);
						}
						break;
					case 5:
						{
						_localctx = new LogicalExpContext(new ExprContext(_parentctx, _parentState));
						pushNewRecursionContext(_localctx, _startState, RULE_expr);
						setState(276);
						if (!(precpred(_ctx, 12))) throw new FailedPredicateException(this, "precpred(_ctx, 12)");
						setState(277);
						_la = _input.LA(1);
						if ( !(_la==AND || _la==OR) ) {
						_errHandler.recoverInline(this);
						}
						else {
							if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
							_errHandler.reportMatch(this);
							consume();
						}
						setState(278);
						expr(13);
						}
						break;
					case 6:
						{
						_localctx = new PostIncExpContext(new ExprContext(_parentctx, _parentState));
						pushNewRecursionContext(_localctx, _startState, RULE_expr);
						setState(279);
						if (!(precpred(_ctx, 10))) throw new FailedPredicateException(this, "precpred(_ctx, 10)");
						setState(280);
						match(INCREMENT);
						}
						break;
					case 7:
						{
						_localctx = new PostDecExpContext(new ExprContext(_parentctx, _parentState));
						pushNewRecursionContext(_localctx, _startState, RULE_expr);
						setState(281);
						if (!(precpred(_ctx, 8))) throw new FailedPredicateException(this, "precpred(_ctx, 8)");
						setState(282);
						match(DECREMENT);
						}
						break;
					}
					} 
				}
				setState(287);
				_errHandler.sync(this);
				_alt = getInterpreter().adaptivePredict(_input,28,_ctx);
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			unrollRecursionContexts(_parentctx);
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class Function_callContext extends ParserRuleContext {
		public TerminalNode ID() { return getToken(CompilatorLFCParser.ID, 0); }
		public TerminalNode OPEN_PARAM() { return getToken(CompilatorLFCParser.OPEN_PARAM, 0); }
		public TerminalNode CLOSE_PARAM() { return getToken(CompilatorLFCParser.CLOSE_PARAM, 0); }
		public Argument_listContext argument_list() {
			return getRuleContext(Argument_listContext.class,0);
		}
		public Function_callContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_function_call; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof CompilatorLFCListener ) ((CompilatorLFCListener)listener).enterFunction_call(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof CompilatorLFCListener ) ((CompilatorLFCListener)listener).exitFunction_call(this);
		}
	}

	public final Function_callContext function_call() throws RecognitionException {
		Function_callContext _localctx = new Function_callContext(_ctx, getState());
		enterRule(_localctx, 52, RULE_function_call);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(288);
			match(ID);
			setState(289);
			match(OPEN_PARAM);
			setState(291);
			_errHandler.sync(this);
			_la = _input.LA(1);
			if ((((_la) & ~0x3f) == 0 && ((1L << _la) & 51694630076416L) != 0)) {
				{
				setState(290);
				argument_list();
				}
			}

			setState(293);
			match(CLOSE_PARAM);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class Argument_listContext extends ParserRuleContext {
		public List<ExprContext> expr() {
			return getRuleContexts(ExprContext.class);
		}
		public ExprContext expr(int i) {
			return getRuleContext(ExprContext.class,i);
		}
		public List<TerminalNode> COMMA() { return getTokens(CompilatorLFCParser.COMMA); }
		public TerminalNode COMMA(int i) {
			return getToken(CompilatorLFCParser.COMMA, i);
		}
		public Argument_listContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_argument_list; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof CompilatorLFCListener ) ((CompilatorLFCListener)listener).enterArgument_list(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof CompilatorLFCListener ) ((CompilatorLFCListener)listener).exitArgument_list(this);
		}
	}

	public final Argument_listContext argument_list() throws RecognitionException {
		Argument_listContext _localctx = new Argument_listContext(_ctx, getState());
		enterRule(_localctx, 54, RULE_argument_list);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(295);
			expr(0);
			setState(300);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (_la==COMMA) {
				{
				{
				setState(296);
				match(COMMA);
				setState(297);
				expr(0);
				}
				}
				setState(302);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public boolean sempred(RuleContext _localctx, int ruleIndex, int predIndex) {
		switch (ruleIndex) {
		case 25:
			return expr_sempred((ExprContext)_localctx, predIndex);
		}
		return true;
	}
	private boolean expr_sempred(ExprContext _localctx, int predIndex) {
		switch (predIndex) {
		case 0:
			return precpred(_ctx, 16);
		case 1:
			return precpred(_ctx, 15);
		case 2:
			return precpred(_ctx, 14);
		case 3:
			return precpred(_ctx, 13);
		case 4:
			return precpred(_ctx, 12);
		case 5:
			return precpred(_ctx, 10);
		case 6:
			return precpred(_ctx, 8);
		}
		return true;
	}

	public static final String _serializedATN =
		"\u0004\u00010\u0130\u0002\u0000\u0007\u0000\u0002\u0001\u0007\u0001\u0002"+
		"\u0002\u0007\u0002\u0002\u0003\u0007\u0003\u0002\u0004\u0007\u0004\u0002"+
		"\u0005\u0007\u0005\u0002\u0006\u0007\u0006\u0002\u0007\u0007\u0007\u0002"+
		"\b\u0007\b\u0002\t\u0007\t\u0002\n\u0007\n\u0002\u000b\u0007\u000b\u0002"+
		"\f\u0007\f\u0002\r\u0007\r\u0002\u000e\u0007\u000e\u0002\u000f\u0007\u000f"+
		"\u0002\u0010\u0007\u0010\u0002\u0011\u0007\u0011\u0002\u0012\u0007\u0012"+
		"\u0002\u0013\u0007\u0013\u0002\u0014\u0007\u0014\u0002\u0015\u0007\u0015"+
		"\u0002\u0016\u0007\u0016\u0002\u0017\u0007\u0017\u0002\u0018\u0007\u0018"+
		"\u0002\u0019\u0007\u0019\u0002\u001a\u0007\u001a\u0002\u001b\u0007\u001b"+
		"\u0001\u0000\u0005\u0000:\b\u0000\n\u0000\f\u0000=\t\u0000\u0001\u0000"+
		"\u0001\u0000\u0001\u0000\u0001\u0001\u0001\u0001\u0001\u0001\u0001\u0001"+
		"\u0003\u0001F\b\u0001\u0001\u0002\u0001\u0002\u0001\u0002\u0001\u0002"+
		"\u0001\u0002\u0001\u0002\u0001\u0003\u0001\u0003\u0001\u0003\u0001\u0004"+
		"\u0003\u0004R\b\u0004\u0001\u0004\u0001\u0004\u0001\u0004\u0001\u0004"+
		"\u0003\u0004X\b\u0004\u0001\u0004\u0001\u0004\u0001\u0005\u0001\u0005"+
		"\u0003\u0005^\b\u0005\u0001\u0006\u0001\u0006\u0001\u0006\u0005\u0006"+
		"c\b\u0006\n\u0006\f\u0006f\t\u0006\u0001\u0007\u0001\u0007\u0001\u0007"+
		"\u0001\b\u0001\b\u0005\bm\b\b\n\b\f\bp\t\b\u0001\b\u0001\b\u0001\t\u0001"+
		"\t\u0001\t\u0001\t\u0001\t\u0001\t\u0001\t\u0001\t\u0001\t\u0001\t\u0001"+
		"\t\u0001\t\u0001\t\u0003\t\u0081\b\t\u0001\n\u0003\n\u0084\b\n\u0001\n"+
		"\u0001\n\u0001\n\u0001\n\u0003\n\u008a\b\n\u0001\u000b\u0001\u000b\u0001"+
		"\f\u0001\f\u0003\f\u0090\b\f\u0001\f\u0001\f\u0001\r\u0001\r\u0001\r\u0003"+
		"\r\u0097\b\r\u0001\r\u0001\r\u0001\r\u0003\r\u009c\b\r\u0001\r\u0001\r"+
		"\u0005\r\u00a0\b\r\n\r\f\r\u00a3\t\r\u0001\r\u0001\r\u0001\r\u0001\r\u0003"+
		"\r\u00a9\b\r\u0001\u000e\u0001\u000e\u0001\u000e\u0001\u000e\u0001\u000f"+
		"\u0001\u000f\u0001\u0010\u0001\u0010\u0001\u0011\u0001\u0011\u0001\u0012"+
		"\u0001\u0012\u0001\u0012\u0001\u0012\u0001\u0012\u0001\u0013\u0001\u0013"+
		"\u0001\u0013\u0003\u0013\u00bd\b\u0013\u0001\u0013\u0001\u0013\u0001\u0013"+
		"\u0003\u0013\u00c2\b\u0013\u0001\u0013\u0001\u0013\u0005\u0013\u00c6\b"+
		"\u0013\n\u0013\f\u0013\u00c9\t\u0013\u0001\u0013\u0001\u0013\u0001\u0013"+
		"\u0001\u0014\u0001\u0014\u0001\u0014\u0003\u0014\u00d1\b\u0014\u0001\u0014"+
		"\u0001\u0014\u0003\u0014\u00d5\b\u0014\u0001\u0014\u0001\u0014\u0003\u0014"+
		"\u00d9\b\u0014\u0001\u0014\u0001\u0014\u0001\u0014\u0001\u0015\u0001\u0015"+
		"\u0003\u0015\u00e0\b\u0015\u0001\u0016\u0003\u0016\u00e3\b\u0016\u0001"+
		"\u0016\u0001\u0016\u0001\u0016\u0003\u0016\u00e8\b\u0016\u0001\u0016\u0001"+
		"\u0016\u0003\u0016\u00ec\b\u0016\u0001\u0017\u0001\u0017\u0003\u0017\u00f0"+
		"\b\u0017\u0001\u0018\u0001\u0018\u0001\u0018\u0001\u0018\u0001\u0019\u0001"+
		"\u0019\u0001\u0019\u0001\u0019\u0001\u0019\u0001\u0019\u0001\u0019\u0001"+
		"\u0019\u0001\u0019\u0001\u0019\u0001\u0019\u0001\u0019\u0001\u0019\u0001"+
		"\u0019\u0001\u0019\u0001\u0019\u0001\u0019\u0003\u0019\u0107\b\u0019\u0001"+
		"\u0019\u0001\u0019\u0001\u0019\u0001\u0019\u0001\u0019\u0001\u0019\u0001"+
		"\u0019\u0001\u0019\u0001\u0019\u0001\u0019\u0001\u0019\u0001\u0019\u0001"+
		"\u0019\u0001\u0019\u0001\u0019\u0001\u0019\u0001\u0019\u0001\u0019\u0001"+
		"\u0019\u0005\u0019\u011c\b\u0019\n\u0019\f\u0019\u011f\t\u0019\u0001\u001a"+
		"\u0001\u001a\u0001\u001a\u0003\u001a\u0124\b\u001a\u0001\u001a\u0001\u001a"+
		"\u0001\u001b\u0001\u001b\u0001\u001b\u0005\u001b\u012b\b\u001b\n\u001b"+
		"\f\u001b\u012e\t\u001b\u0001\u001b\u0000\u00012\u001c\u0000\u0002\u0004"+
		"\u0006\b\n\f\u000e\u0010\u0012\u0014\u0016\u0018\u001a\u001c\u001e \""+
		"$&(*,.0246\u0000\b\u0001\u0000\u0001\u0004\u0001\u0000\f\u0011\u0001\u0000"+
		"\u0012\u0013\u0001\u0000\u0015\u001a\u0001\u0000\u001f!\u0001\u0000\u001d"+
		"\u001e\u0002\u0000\f\r\u000f\u0010\u0002\u0000\u000e\u000e\u0011\u0011"+
		"\u0146\u0000;\u0001\u0000\u0000\u0000\u0002E\u0001\u0000\u0000\u0000\u0004"+
		"G\u0001\u0000\u0000\u0000\u0006M\u0001\u0000\u0000\u0000\bQ\u0001\u0000"+
		"\u0000\u0000\n]\u0001\u0000\u0000\u0000\f_\u0001\u0000\u0000\u0000\u000e"+
		"g\u0001\u0000\u0000\u0000\u0010j\u0001\u0000\u0000\u0000\u0012\u0080\u0001"+
		"\u0000\u0000\u0000\u0014\u0083\u0001\u0000\u0000\u0000\u0016\u008b\u0001"+
		"\u0000\u0000\u0000\u0018\u008d\u0001\u0000\u0000\u0000\u001a\u0093\u0001"+
		"\u0000\u0000\u0000\u001c\u00aa\u0001\u0000\u0000\u0000\u001e\u00ae\u0001"+
		"\u0000\u0000\u0000 \u00b0\u0001\u0000\u0000\u0000\"\u00b2\u0001\u0000"+
		"\u0000\u0000$\u00b4\u0001\u0000\u0000\u0000&\u00b9\u0001\u0000\u0000\u0000"+
		"(\u00cd\u0001\u0000\u0000\u0000*\u00df\u0001\u0000\u0000\u0000,\u00e2"+
		"\u0001\u0000\u0000\u0000.\u00ef\u0001\u0000\u0000\u00000\u00f1\u0001\u0000"+
		"\u0000\u00002\u0106\u0001\u0000\u0000\u00004\u0120\u0001\u0000\u0000\u0000"+
		"6\u0127\u0001\u0000\u0000\u00008:\u0003\u0002\u0001\u000098\u0001\u0000"+
		"\u0000\u0000:=\u0001\u0000\u0000\u0000;9\u0001\u0000\u0000\u0000;<\u0001"+
		"\u0000\u0000\u0000<>\u0001\u0000\u0000\u0000=;\u0001\u0000\u0000\u0000"+
		">?\u0003\u0004\u0002\u0000?@\u0005\u0000\u0000\u0001@\u0001\u0001\u0000"+
		"\u0000\u0000AB\u0003\u0014\n\u0000BC\u0005\'\u0000\u0000CF\u0001\u0000"+
		"\u0000\u0000DF\u0003\u0006\u0003\u0000EA\u0001\u0000\u0000\u0000ED\u0001"+
		"\u0000\u0000\u0000F\u0003\u0001\u0000\u0000\u0000GH\u0005\u0001\u0000"+
		"\u0000HI\u0005,\u0000\u0000IJ\u0005\"\u0000\u0000JK\u0005#\u0000\u0000"+
		"KL\u0003\u0010\b\u0000L\u0005\u0001\u0000\u0000\u0000MN\u0003\b\u0004"+
		"\u0000NO\u0003\u0010\b\u0000O\u0007\u0001\u0000\u0000\u0000PR\u0005\u0005"+
		"\u0000\u0000QP\u0001\u0000\u0000\u0000QR\u0001\u0000\u0000\u0000RS\u0001"+
		"\u0000\u0000\u0000ST\u0003\n\u0005\u0000TU\u0005-\u0000\u0000UW\u0005"+
		"\"\u0000\u0000VX\u0003\f\u0006\u0000WV\u0001\u0000\u0000\u0000WX\u0001"+
		"\u0000\u0000\u0000XY\u0001\u0000\u0000\u0000YZ\u0005#\u0000\u0000Z\t\u0001"+
		"\u0000\u0000\u0000[^\u0005\u0006\u0000\u0000\\^\u0003\u0016\u000b\u0000"+
		"][\u0001\u0000\u0000\u0000]\\\u0001\u0000\u0000\u0000^\u000b\u0001\u0000"+
		"\u0000\u0000_d\u0003\u000e\u0007\u0000`a\u0005&\u0000\u0000ac\u0003\u000e"+
		"\u0007\u0000b`\u0001\u0000\u0000\u0000cf\u0001\u0000\u0000\u0000db\u0001"+
		"\u0000\u0000\u0000de\u0001\u0000\u0000\u0000e\r\u0001\u0000\u0000\u0000"+
		"fd\u0001\u0000\u0000\u0000gh\u0003\u0016\u000b\u0000hi\u0005-\u0000\u0000"+
		"i\u000f\u0001\u0000\u0000\u0000jn\u0005$\u0000\u0000km\u0003\u0012\t\u0000"+
		"lk\u0001\u0000\u0000\u0000mp\u0001\u0000\u0000\u0000nl\u0001\u0000\u0000"+
		"\u0000no\u0001\u0000\u0000\u0000oq\u0001\u0000\u0000\u0000pn\u0001\u0000"+
		"\u0000\u0000qr\u0005%\u0000\u0000r\u0011\u0001\u0000\u0000\u0000st\u0003"+
		"\u0014\n\u0000tu\u0005\'\u0000\u0000u\u0081\u0001\u0000\u0000\u0000v\u0081"+
		"\u0003$\u0012\u0000wx\u00032\u0019\u0000xy\u0005\'\u0000\u0000y\u0081"+
		"\u0001\u0000\u0000\u0000z\u0081\u0003\u001a\r\u0000{\u0081\u0003\u0018"+
		"\f\u0000|\u0081\u0003&\u0013\u0000}\u0081\u0003(\u0014\u0000~\u0081\u0003"+
		"4\u001a\u0000\u007f\u0081\u0003\u0010\b\u0000\u0080s\u0001\u0000\u0000"+
		"\u0000\u0080v\u0001\u0000\u0000\u0000\u0080w\u0001\u0000\u0000\u0000\u0080"+
		"z\u0001\u0000\u0000\u0000\u0080{\u0001\u0000\u0000\u0000\u0080|\u0001"+
		"\u0000\u0000\u0000\u0080}\u0001\u0000\u0000\u0000\u0080~\u0001\u0000\u0000"+
		"\u0000\u0080\u007f\u0001\u0000\u0000\u0000\u0081\u0013\u0001\u0000\u0000"+
		"\u0000\u0082\u0084\u0005\u0005\u0000\u0000\u0083\u0082\u0001\u0000\u0000"+
		"\u0000\u0083\u0084\u0001\u0000\u0000\u0000\u0084\u0085\u0001\u0000\u0000"+
		"\u0000\u0085\u0086\u0003\u0016\u000b\u0000\u0086\u0089\u0005-\u0000\u0000"+
		"\u0087\u0088\u0005\u001a\u0000\u0000\u0088\u008a\u00032\u0019\u0000\u0089"+
		"\u0087\u0001\u0000\u0000\u0000\u0089\u008a\u0001\u0000\u0000\u0000\u008a"+
		"\u0015\u0001\u0000\u0000\u0000\u008b\u008c\u0007\u0000\u0000\u0000\u008c"+
		"\u0017\u0001\u0000\u0000\u0000\u008d\u008f\u0005\u000b\u0000\u0000\u008e"+
		"\u0090\u00032\u0019\u0000\u008f\u008e\u0001\u0000\u0000\u0000\u008f\u0090"+
		"\u0001\u0000\u0000\u0000\u0090\u0091\u0001\u0000\u0000\u0000\u0091\u0092"+
		"\u0005\'\u0000\u0000\u0092\u0019\u0001\u0000\u0000\u0000\u0093\u0094\u0005"+
		"\u0007\u0000\u0000\u0094\u0096\u0005\"\u0000\u0000\u0095\u0097\u0005\u0014"+
		"\u0000\u0000\u0096\u0095\u0001\u0000\u0000\u0000\u0096\u0097\u0001\u0000"+
		"\u0000\u0000\u0097\u0098\u0001\u0000\u0000\u0000\u0098\u00a1\u0003\u001c"+
		"\u000e\u0000\u0099\u009b\u0003 \u0010\u0000\u009a\u009c\u0005\u0014\u0000"+
		"\u0000\u009b\u009a\u0001\u0000\u0000\u0000\u009b\u009c\u0001\u0000\u0000"+
		"\u0000\u009c\u009d\u0001\u0000\u0000\u0000\u009d\u009e\u0003\u001c\u000e"+
		"\u0000\u009e\u00a0\u0001\u0000\u0000\u0000\u009f\u0099\u0001\u0000\u0000"+
		"\u0000\u00a0\u00a3\u0001\u0000\u0000\u0000\u00a1\u009f\u0001\u0000\u0000"+
		"\u0000\u00a1\u00a2\u0001\u0000\u0000\u0000\u00a2\u00a4\u0001\u0000\u0000"+
		"\u0000\u00a3\u00a1\u0001\u0000\u0000\u0000\u00a4\u00a5\u0005#\u0000\u0000"+
		"\u00a5\u00a8\u0003\u0012\t\u0000\u00a6\u00a7\u0005\b\u0000\u0000\u00a7"+
		"\u00a9\u0003\u0012\t\u0000\u00a8\u00a6\u0001\u0000\u0000\u0000\u00a8\u00a9"+
		"\u0001\u0000\u0000\u0000\u00a9\u001b\u0001\u0000\u0000\u0000\u00aa\u00ab"+
		"\u00032\u0019\u0000\u00ab\u00ac\u0003\u001e\u000f\u0000\u00ac\u00ad\u0003"+
		"2\u0019\u0000\u00ad\u001d\u0001\u0000\u0000\u0000\u00ae\u00af\u0007\u0001"+
		"\u0000\u0000\u00af\u001f\u0001\u0000\u0000\u0000\u00b0\u00b1\u0007\u0002"+
		"\u0000\u0000\u00b1!\u0001\u0000\u0000\u0000\u00b2\u00b3\u0007\u0003\u0000"+
		"\u0000\u00b3#\u0001\u0000\u0000\u0000\u00b4\u00b5\u0005-\u0000\u0000\u00b5"+
		"\u00b6\u0003\"\u0011\u0000\u00b6\u00b7\u00032\u0019\u0000\u00b7\u00b8"+
		"\u0005\'\u0000\u0000\u00b8%\u0001\u0000\u0000\u0000\u00b9\u00ba\u0005"+
		"\n\u0000\u0000\u00ba\u00bc\u0005\"\u0000\u0000\u00bb\u00bd\u0005\u0014"+
		"\u0000\u0000\u00bc\u00bb\u0001\u0000\u0000\u0000\u00bc\u00bd\u0001\u0000"+
		"\u0000\u0000\u00bd\u00be\u0001\u0000\u0000\u0000\u00be\u00c7\u0003\u001c"+
		"\u000e\u0000\u00bf\u00c1\u0003 \u0010\u0000\u00c0\u00c2\u0005\u0014\u0000"+
		"\u0000\u00c1\u00c0\u0001\u0000\u0000\u0000\u00c1\u00c2\u0001\u0000\u0000"+
		"\u0000\u00c2\u00c3\u0001\u0000\u0000\u0000\u00c3\u00c4\u0003\u001c\u000e"+
		"\u0000\u00c4\u00c6\u0001\u0000\u0000\u0000\u00c5\u00bf\u0001\u0000\u0000"+
		"\u0000\u00c6\u00c9\u0001\u0000\u0000\u0000\u00c7\u00c5\u0001\u0000\u0000"+
		"\u0000\u00c7\u00c8\u0001\u0000\u0000\u0000\u00c8\u00ca\u0001\u0000\u0000"+
		"\u0000\u00c9\u00c7\u0001\u0000\u0000\u0000\u00ca\u00cb\u0005#\u0000\u0000"+
		"\u00cb\u00cc\u0003\u0012\t\u0000\u00cc\'\u0001\u0000\u0000\u0000\u00cd"+
		"\u00ce\u0005\t\u0000\u0000\u00ce\u00d0\u0005\"\u0000\u0000\u00cf\u00d1"+
		"\u0003*\u0015\u0000\u00d0\u00cf\u0001\u0000\u0000\u0000\u00d0\u00d1\u0001"+
		"\u0000\u0000\u0000\u00d1\u00d2\u0001\u0000\u0000\u0000\u00d2\u00d4\u0005"+
		"\'\u0000\u0000\u00d3\u00d5\u0003,\u0016\u0000\u00d4\u00d3\u0001\u0000"+
		"\u0000\u0000\u00d4\u00d5\u0001\u0000\u0000\u0000\u00d5\u00d6\u0001\u0000"+
		"\u0000\u0000\u00d6\u00d8\u0005\'\u0000\u0000\u00d7\u00d9\u0003.\u0017"+
		"\u0000\u00d8\u00d7\u0001\u0000\u0000\u0000\u00d8\u00d9\u0001\u0000\u0000"+
		"\u0000\u00d9\u00da\u0001\u0000\u0000\u0000\u00da\u00db\u0005#\u0000\u0000"+
		"\u00db\u00dc\u0003\u0012\t\u0000\u00dc)\u0001\u0000\u0000\u0000\u00dd"+
		"\u00e0\u0003\u0014\n\u0000\u00de\u00e0\u00030\u0018\u0000\u00df\u00dd"+
		"\u0001\u0000\u0000\u0000\u00df\u00de\u0001\u0000\u0000\u0000\u00e0+\u0001"+
		"\u0000\u0000\u0000\u00e1\u00e3\u0005\u0014\u0000\u0000\u00e2\u00e1\u0001"+
		"\u0000\u0000\u0000\u00e2\u00e3\u0001\u0000\u0000\u0000\u00e3\u00e4\u0001"+
		"\u0000\u0000\u0000\u00e4\u00eb\u0003\u001c\u000e\u0000\u00e5\u00e7\u0003"+
		" \u0010\u0000\u00e6\u00e8\u0005\u0014\u0000\u0000\u00e7\u00e6\u0001\u0000"+
		"\u0000\u0000\u00e7\u00e8\u0001\u0000\u0000\u0000\u00e8\u00e9\u0001\u0000"+
		"\u0000\u0000\u00e9\u00ea\u0003\u001c\u000e\u0000\u00ea\u00ec\u0001\u0000"+
		"\u0000\u0000\u00eb\u00e5\u0001\u0000\u0000\u0000\u00eb\u00ec\u0001\u0000"+
		"\u0000\u0000\u00ec-\u0001\u0000\u0000\u0000\u00ed\u00f0\u00030\u0018\u0000"+
		"\u00ee\u00f0\u00032\u0019\u0000\u00ef\u00ed\u0001\u0000\u0000\u0000\u00ef"+
		"\u00ee\u0001\u0000\u0000\u0000\u00f0/\u0001\u0000\u0000\u0000\u00f1\u00f2"+
		"\u0005-\u0000\u0000\u00f2\u00f3\u0003\"\u0011\u0000\u00f3\u00f4\u0003"+
		"2\u0019\u0000\u00f41\u0001\u0000\u0000\u0000\u00f5\u00f6\u0006\u0019\uffff"+
		"\uffff\u0000\u00f6\u00f7\u0005\"\u0000\u0000\u00f7\u00f8\u00032\u0019"+
		"\u0000\u00f8\u00f9\u0005#\u0000\u0000\u00f9\u0107\u0001\u0000\u0000\u0000"+
		"\u00fa\u00fb\u0005\u0014\u0000\u0000\u00fb\u0107\u00032\u0019\u000b\u00fc"+
		"\u00fd\u0005\u001b\u0000\u0000\u00fd\u0107\u00032\u0019\t\u00fe\u00ff"+
		"\u0005\u001c\u0000\u0000\u00ff\u0107\u00032\u0019\u0007\u0100\u0107\u0003"+
		"4\u001a\u0000\u0101\u0107\u0005-\u0000\u0000\u0102\u0107\u0005(\u0000"+
		"\u0000\u0103\u0107\u0005)\u0000\u0000\u0104\u0107\u0005*\u0000\u0000\u0105"+
		"\u0107\u0005+\u0000\u0000\u0106\u00f5\u0001\u0000\u0000\u0000\u0106\u00fa"+
		"\u0001\u0000\u0000\u0000\u0106\u00fc\u0001\u0000\u0000\u0000\u0106\u00fe"+
		"\u0001\u0000\u0000\u0000\u0106\u0100\u0001\u0000\u0000\u0000\u0106\u0101"+
		"\u0001\u0000\u0000\u0000\u0106\u0102\u0001\u0000\u0000\u0000\u0106\u0103"+
		"\u0001\u0000\u0000\u0000\u0106\u0104\u0001\u0000\u0000\u0000\u0106\u0105"+
		"\u0001\u0000\u0000\u0000\u0107\u011d\u0001\u0000\u0000\u0000\u0108\u0109"+
		"\n\u0010\u0000\u0000\u0109\u010a\u0007\u0004\u0000\u0000\u010a\u011c\u0003"+
		"2\u0019\u0011\u010b\u010c\n\u000f\u0000\u0000\u010c\u010d\u0007\u0005"+
		"\u0000\u0000\u010d\u011c\u00032\u0019\u0010\u010e\u010f\n\u000e\u0000"+
		"\u0000\u010f\u0110\u0007\u0006\u0000\u0000\u0110\u011c\u00032\u0019\u000f"+
		"\u0111\u0112\n\r\u0000\u0000\u0112\u0113\u0007\u0007\u0000\u0000\u0113"+
		"\u011c\u00032\u0019\u000e\u0114\u0115\n\f\u0000\u0000\u0115\u0116\u0007"+
		"\u0002\u0000\u0000\u0116\u011c\u00032\u0019\r\u0117\u0118\n\n\u0000\u0000"+
		"\u0118\u011c\u0005\u001b\u0000\u0000\u0119\u011a\n\b\u0000\u0000\u011a"+
		"\u011c\u0005\u001c\u0000\u0000\u011b\u0108\u0001\u0000\u0000\u0000\u011b"+
		"\u010b\u0001\u0000\u0000\u0000\u011b\u010e\u0001\u0000\u0000\u0000\u011b"+
		"\u0111\u0001\u0000\u0000\u0000\u011b\u0114\u0001\u0000\u0000\u0000\u011b"+
		"\u0117\u0001\u0000\u0000\u0000\u011b\u0119\u0001\u0000\u0000\u0000\u011c"+
		"\u011f\u0001\u0000\u0000\u0000\u011d\u011b\u0001\u0000\u0000\u0000\u011d"+
		"\u011e\u0001\u0000\u0000\u0000\u011e3\u0001\u0000\u0000\u0000\u011f\u011d"+
		"\u0001\u0000\u0000\u0000\u0120\u0121\u0005-\u0000\u0000\u0121\u0123\u0005"+
		"\"\u0000\u0000\u0122\u0124\u00036\u001b\u0000\u0123\u0122\u0001\u0000"+
		"\u0000\u0000\u0123\u0124\u0001\u0000\u0000\u0000\u0124\u0125\u0001\u0000"+
		"\u0000\u0000\u0125\u0126\u0005#\u0000\u0000\u01265\u0001\u0000\u0000\u0000"+
		"\u0127\u012c\u00032\u0019\u0000\u0128\u0129\u0005&\u0000\u0000\u0129\u012b"+
		"\u00032\u0019\u0000\u012a\u0128\u0001\u0000\u0000\u0000\u012b\u012e\u0001"+
		"\u0000\u0000\u0000\u012c\u012a\u0001\u0000\u0000\u0000\u012c\u012d\u0001"+
		"\u0000\u0000\u0000\u012d7\u0001\u0000\u0000\u0000\u012e\u012c\u0001\u0000"+
		"\u0000\u0000\u001f;EQW]dn\u0080\u0083\u0089\u008f\u0096\u009b\u00a1\u00a8"+
		"\u00bc\u00c1\u00c7\u00d0\u00d4\u00d8\u00df\u00e2\u00e7\u00eb\u00ef\u0106"+
		"\u011b\u011d\u0123\u012c";
	public static final ATN _ATN =
		new ATNDeserializer().deserialize(_serializedATN.toCharArray());
	static {
		_decisionToDFA = new DFA[_ATN.getNumberOfDecisions()];
		for (int i = 0; i < _ATN.getNumberOfDecisions(); i++) {
			_decisionToDFA[i] = new DFA(_ATN.getDecisionState(i), i);
		}
	}
}