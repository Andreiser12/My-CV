// Generated from c:/Users/razva/Desktop/An2/LFC/Tema2/CompilatorLFC.g4 by ANTLR 4.13.1
import org.antlr.v4.runtime.tree.ParseTreeListener;

/**
 * This interface defines a complete listener for a parse tree produced by
 * {@link CompilatorLFCParser}.
 */
public interface CompilatorLFCListener extends ParseTreeListener {
	/**
	 * Enter a parse tree produced by {@link CompilatorLFCParser#program}.
	 * @param ctx the parse tree
	 */
	void enterProgram(CompilatorLFCParser.ProgramContext ctx);
	/**
	 * Exit a parse tree produced by {@link CompilatorLFCParser#program}.
	 * @param ctx the parse tree
	 */
	void exitProgram(CompilatorLFCParser.ProgramContext ctx);
	/**
	 * Enter a parse tree produced by {@link CompilatorLFCParser#global_decl}.
	 * @param ctx the parse tree
	 */
	void enterGlobal_decl(CompilatorLFCParser.Global_declContext ctx);
	/**
	 * Exit a parse tree produced by {@link CompilatorLFCParser#global_decl}.
	 * @param ctx the parse tree
	 */
	void exitGlobal_decl(CompilatorLFCParser.Global_declContext ctx);
	/**
	 * Enter a parse tree produced by {@link CompilatorLFCParser#main_function}.
	 * @param ctx the parse tree
	 */
	void enterMain_function(CompilatorLFCParser.Main_functionContext ctx);
	/**
	 * Exit a parse tree produced by {@link CompilatorLFCParser#main_function}.
	 * @param ctx the parse tree
	 */
	void exitMain_function(CompilatorLFCParser.Main_functionContext ctx);
	/**
	 * Enter a parse tree produced by {@link CompilatorLFCParser#function}.
	 * @param ctx the parse tree
	 */
	void enterFunction(CompilatorLFCParser.FunctionContext ctx);
	/**
	 * Exit a parse tree produced by {@link CompilatorLFCParser#function}.
	 * @param ctx the parse tree
	 */
	void exitFunction(CompilatorLFCParser.FunctionContext ctx);
	/**
	 * Enter a parse tree produced by {@link CompilatorLFCParser#func_decl}.
	 * @param ctx the parse tree
	 */
	void enterFunc_decl(CompilatorLFCParser.Func_declContext ctx);
	/**
	 * Exit a parse tree produced by {@link CompilatorLFCParser#func_decl}.
	 * @param ctx the parse tree
	 */
	void exitFunc_decl(CompilatorLFCParser.Func_declContext ctx);
	/**
	 * Enter a parse tree produced by {@link CompilatorLFCParser#func_type}.
	 * @param ctx the parse tree
	 */
	void enterFunc_type(CompilatorLFCParser.Func_typeContext ctx);
	/**
	 * Exit a parse tree produced by {@link CompilatorLFCParser#func_type}.
	 * @param ctx the parse tree
	 */
	void exitFunc_type(CompilatorLFCParser.Func_typeContext ctx);
	/**
	 * Enter a parse tree produced by {@link CompilatorLFCParser#param_list}.
	 * @param ctx the parse tree
	 */
	void enterParam_list(CompilatorLFCParser.Param_listContext ctx);
	/**
	 * Exit a parse tree produced by {@link CompilatorLFCParser#param_list}.
	 * @param ctx the parse tree
	 */
	void exitParam_list(CompilatorLFCParser.Param_listContext ctx);
	/**
	 * Enter a parse tree produced by {@link CompilatorLFCParser#param}.
	 * @param ctx the parse tree
	 */
	void enterParam(CompilatorLFCParser.ParamContext ctx);
	/**
	 * Exit a parse tree produced by {@link CompilatorLFCParser#param}.
	 * @param ctx the parse tree
	 */
	void exitParam(CompilatorLFCParser.ParamContext ctx);
	/**
	 * Enter a parse tree produced by {@link CompilatorLFCParser#block}.
	 * @param ctx the parse tree
	 */
	void enterBlock(CompilatorLFCParser.BlockContext ctx);
	/**
	 * Exit a parse tree produced by {@link CompilatorLFCParser#block}.
	 * @param ctx the parse tree
	 */
	void exitBlock(CompilatorLFCParser.BlockContext ctx);
	/**
	 * Enter a parse tree produced by {@link CompilatorLFCParser#statement}.
	 * @param ctx the parse tree
	 */
	void enterStatement(CompilatorLFCParser.StatementContext ctx);
	/**
	 * Exit a parse tree produced by {@link CompilatorLFCParser#statement}.
	 * @param ctx the parse tree
	 */
	void exitStatement(CompilatorLFCParser.StatementContext ctx);
	/**
	 * Enter a parse tree produced by {@link CompilatorLFCParser#var_decl}.
	 * @param ctx the parse tree
	 */
	void enterVar_decl(CompilatorLFCParser.Var_declContext ctx);
	/**
	 * Exit a parse tree produced by {@link CompilatorLFCParser#var_decl}.
	 * @param ctx the parse tree
	 */
	void exitVar_decl(CompilatorLFCParser.Var_declContext ctx);
	/**
	 * Enter a parse tree produced by {@link CompilatorLFCParser#var_type}.
	 * @param ctx the parse tree
	 */
	void enterVar_type(CompilatorLFCParser.Var_typeContext ctx);
	/**
	 * Exit a parse tree produced by {@link CompilatorLFCParser#var_type}.
	 * @param ctx the parse tree
	 */
	void exitVar_type(CompilatorLFCParser.Var_typeContext ctx);
	/**
	 * Enter a parse tree produced by {@link CompilatorLFCParser#return_statement}.
	 * @param ctx the parse tree
	 */
	void enterReturn_statement(CompilatorLFCParser.Return_statementContext ctx);
	/**
	 * Exit a parse tree produced by {@link CompilatorLFCParser#return_statement}.
	 * @param ctx the parse tree
	 */
	void exitReturn_statement(CompilatorLFCParser.Return_statementContext ctx);
	/**
	 * Enter a parse tree produced by {@link CompilatorLFCParser#if_statement}.
	 * @param ctx the parse tree
	 */
	void enterIf_statement(CompilatorLFCParser.If_statementContext ctx);
	/**
	 * Exit a parse tree produced by {@link CompilatorLFCParser#if_statement}.
	 * @param ctx the parse tree
	 */
	void exitIf_statement(CompilatorLFCParser.If_statementContext ctx);
	/**
	 * Enter a parse tree produced by {@link CompilatorLFCParser#condition}.
	 * @param ctx the parse tree
	 */
	void enterCondition(CompilatorLFCParser.ConditionContext ctx);
	/**
	 * Exit a parse tree produced by {@link CompilatorLFCParser#condition}.
	 * @param ctx the parse tree
	 */
	void exitCondition(CompilatorLFCParser.ConditionContext ctx);
	/**
	 * Enter a parse tree produced by {@link CompilatorLFCParser#relational_op}.
	 * @param ctx the parse tree
	 */
	void enterRelational_op(CompilatorLFCParser.Relational_opContext ctx);
	/**
	 * Exit a parse tree produced by {@link CompilatorLFCParser#relational_op}.
	 * @param ctx the parse tree
	 */
	void exitRelational_op(CompilatorLFCParser.Relational_opContext ctx);
	/**
	 * Enter a parse tree produced by {@link CompilatorLFCParser#logical_op}.
	 * @param ctx the parse tree
	 */
	void enterLogical_op(CompilatorLFCParser.Logical_opContext ctx);
	/**
	 * Exit a parse tree produced by {@link CompilatorLFCParser#logical_op}.
	 * @param ctx the parse tree
	 */
	void exitLogical_op(CompilatorLFCParser.Logical_opContext ctx);
	/**
	 * Enter a parse tree produced by {@link CompilatorLFCParser#assign_op}.
	 * @param ctx the parse tree
	 */
	void enterAssign_op(CompilatorLFCParser.Assign_opContext ctx);
	/**
	 * Exit a parse tree produced by {@link CompilatorLFCParser#assign_op}.
	 * @param ctx the parse tree
	 */
	void exitAssign_op(CompilatorLFCParser.Assign_opContext ctx);
	/**
	 * Enter a parse tree produced by {@link CompilatorLFCParser#assignment_statement}.
	 * @param ctx the parse tree
	 */
	void enterAssignment_statement(CompilatorLFCParser.Assignment_statementContext ctx);
	/**
	 * Exit a parse tree produced by {@link CompilatorLFCParser#assignment_statement}.
	 * @param ctx the parse tree
	 */
	void exitAssignment_statement(CompilatorLFCParser.Assignment_statementContext ctx);
	/**
	 * Enter a parse tree produced by {@link CompilatorLFCParser#while_statement}.
	 * @param ctx the parse tree
	 */
	void enterWhile_statement(CompilatorLFCParser.While_statementContext ctx);
	/**
	 * Exit a parse tree produced by {@link CompilatorLFCParser#while_statement}.
	 * @param ctx the parse tree
	 */
	void exitWhile_statement(CompilatorLFCParser.While_statementContext ctx);
	/**
	 * Enter a parse tree produced by {@link CompilatorLFCParser#for_statement}.
	 * @param ctx the parse tree
	 */
	void enterFor_statement(CompilatorLFCParser.For_statementContext ctx);
	/**
	 * Exit a parse tree produced by {@link CompilatorLFCParser#for_statement}.
	 * @param ctx the parse tree
	 */
	void exitFor_statement(CompilatorLFCParser.For_statementContext ctx);
	/**
	 * Enter a parse tree produced by {@link CompilatorLFCParser#for_init}.
	 * @param ctx the parse tree
	 */
	void enterFor_init(CompilatorLFCParser.For_initContext ctx);
	/**
	 * Exit a parse tree produced by {@link CompilatorLFCParser#for_init}.
	 * @param ctx the parse tree
	 */
	void exitFor_init(CompilatorLFCParser.For_initContext ctx);
	/**
	 * Enter a parse tree produced by {@link CompilatorLFCParser#for_condition}.
	 * @param ctx the parse tree
	 */
	void enterFor_condition(CompilatorLFCParser.For_conditionContext ctx);
	/**
	 * Exit a parse tree produced by {@link CompilatorLFCParser#for_condition}.
	 * @param ctx the parse tree
	 */
	void exitFor_condition(CompilatorLFCParser.For_conditionContext ctx);
	/**
	 * Enter a parse tree produced by {@link CompilatorLFCParser#for_step}.
	 * @param ctx the parse tree
	 */
	void enterFor_step(CompilatorLFCParser.For_stepContext ctx);
	/**
	 * Exit a parse tree produced by {@link CompilatorLFCParser#for_step}.
	 * @param ctx the parse tree
	 */
	void exitFor_step(CompilatorLFCParser.For_stepContext ctx);
	/**
	 * Enter a parse tree produced by {@link CompilatorLFCParser#assignment_statement_no_semi}.
	 * @param ctx the parse tree
	 */
	void enterAssignment_statement_no_semi(CompilatorLFCParser.Assignment_statement_no_semiContext ctx);
	/**
	 * Exit a parse tree produced by {@link CompilatorLFCParser#assignment_statement_no_semi}.
	 * @param ctx the parse tree
	 */
	void exitAssignment_statement_no_semi(CompilatorLFCParser.Assignment_statement_no_semiContext ctx);
	/**
	 * Enter a parse tree produced by the {@code doubleLiteralExp}
	 * labeled alternative in {@link CompilatorLFCParser#expr}.
	 * @param ctx the parse tree
	 */
	void enterDoubleLiteralExp(CompilatorLFCParser.DoubleLiteralExpContext ctx);
	/**
	 * Exit a parse tree produced by the {@code doubleLiteralExp}
	 * labeled alternative in {@link CompilatorLFCParser#expr}.
	 * @param ctx the parse tree
	 */
	void exitDoubleLiteralExp(CompilatorLFCParser.DoubleLiteralExpContext ctx);
	/**
	 * Enter a parse tree produced by the {@code stringLiteralExp}
	 * labeled alternative in {@link CompilatorLFCParser#expr}.
	 * @param ctx the parse tree
	 */
	void enterStringLiteralExp(CompilatorLFCParser.StringLiteralExpContext ctx);
	/**
	 * Exit a parse tree produced by the {@code stringLiteralExp}
	 * labeled alternative in {@link CompilatorLFCParser#expr}.
	 * @param ctx the parse tree
	 */
	void exitStringLiteralExp(CompilatorLFCParser.StringLiteralExpContext ctx);
	/**
	 * Enter a parse tree produced by the {@code equalityExp}
	 * labeled alternative in {@link CompilatorLFCParser#expr}.
	 * @param ctx the parse tree
	 */
	void enterEqualityExp(CompilatorLFCParser.EqualityExpContext ctx);
	/**
	 * Exit a parse tree produced by the {@code equalityExp}
	 * labeled alternative in {@link CompilatorLFCParser#expr}.
	 * @param ctx the parse tree
	 */
	void exitEqualityExp(CompilatorLFCParser.EqualityExpContext ctx);
	/**
	 * Enter a parse tree produced by the {@code floatLiteralExp}
	 * labeled alternative in {@link CompilatorLFCParser#expr}.
	 * @param ctx the parse tree
	 */
	void enterFloatLiteralExp(CompilatorLFCParser.FloatLiteralExpContext ctx);
	/**
	 * Exit a parse tree produced by the {@code floatLiteralExp}
	 * labeled alternative in {@link CompilatorLFCParser#expr}.
	 * @param ctx the parse tree
	 */
	void exitFloatLiteralExp(CompilatorLFCParser.FloatLiteralExpContext ctx);
	/**
	 * Enter a parse tree produced by the {@code postIncExp}
	 * labeled alternative in {@link CompilatorLFCParser#expr}.
	 * @param ctx the parse tree
	 */
	void enterPostIncExp(CompilatorLFCParser.PostIncExpContext ctx);
	/**
	 * Exit a parse tree produced by the {@code postIncExp}
	 * labeled alternative in {@link CompilatorLFCParser#expr}.
	 * @param ctx the parse tree
	 */
	void exitPostIncExp(CompilatorLFCParser.PostIncExpContext ctx);
	/**
	 * Enter a parse tree produced by the {@code preDecExp}
	 * labeled alternative in {@link CompilatorLFCParser#expr}.
	 * @param ctx the parse tree
	 */
	void enterPreDecExp(CompilatorLFCParser.PreDecExpContext ctx);
	/**
	 * Exit a parse tree produced by the {@code preDecExp}
	 * labeled alternative in {@link CompilatorLFCParser#expr}.
	 * @param ctx the parse tree
	 */
	void exitPreDecExp(CompilatorLFCParser.PreDecExpContext ctx);
	/**
	 * Enter a parse tree produced by the {@code funcCallExp}
	 * labeled alternative in {@link CompilatorLFCParser#expr}.
	 * @param ctx the parse tree
	 */
	void enterFuncCallExp(CompilatorLFCParser.FuncCallExpContext ctx);
	/**
	 * Exit a parse tree produced by the {@code funcCallExp}
	 * labeled alternative in {@link CompilatorLFCParser#expr}.
	 * @param ctx the parse tree
	 */
	void exitFuncCallExp(CompilatorLFCParser.FuncCallExpContext ctx);
	/**
	 * Enter a parse tree produced by the {@code notExp}
	 * labeled alternative in {@link CompilatorLFCParser#expr}.
	 * @param ctx the parse tree
	 */
	void enterNotExp(CompilatorLFCParser.NotExpContext ctx);
	/**
	 * Exit a parse tree produced by the {@code notExp}
	 * labeled alternative in {@link CompilatorLFCParser#expr}.
	 * @param ctx the parse tree
	 */
	void exitNotExp(CompilatorLFCParser.NotExpContext ctx);
	/**
	 * Enter a parse tree produced by the {@code addSubExp}
	 * labeled alternative in {@link CompilatorLFCParser#expr}.
	 * @param ctx the parse tree
	 */
	void enterAddSubExp(CompilatorLFCParser.AddSubExpContext ctx);
	/**
	 * Exit a parse tree produced by the {@code addSubExp}
	 * labeled alternative in {@link CompilatorLFCParser#expr}.
	 * @param ctx the parse tree
	 */
	void exitAddSubExp(CompilatorLFCParser.AddSubExpContext ctx);
	/**
	 * Enter a parse tree produced by the {@code idExp}
	 * labeled alternative in {@link CompilatorLFCParser#expr}.
	 * @param ctx the parse tree
	 */
	void enterIdExp(CompilatorLFCParser.IdExpContext ctx);
	/**
	 * Exit a parse tree produced by the {@code idExp}
	 * labeled alternative in {@link CompilatorLFCParser#expr}.
	 * @param ctx the parse tree
	 */
	void exitIdExp(CompilatorLFCParser.IdExpContext ctx);
	/**
	 * Enter a parse tree produced by the {@code mulDivModExp}
	 * labeled alternative in {@link CompilatorLFCParser#expr}.
	 * @param ctx the parse tree
	 */
	void enterMulDivModExp(CompilatorLFCParser.MulDivModExpContext ctx);
	/**
	 * Exit a parse tree produced by the {@code mulDivModExp}
	 * labeled alternative in {@link CompilatorLFCParser#expr}.
	 * @param ctx the parse tree
	 */
	void exitMulDivModExp(CompilatorLFCParser.MulDivModExpContext ctx);
	/**
	 * Enter a parse tree produced by the {@code postDecExp}
	 * labeled alternative in {@link CompilatorLFCParser#expr}.
	 * @param ctx the parse tree
	 */
	void enterPostDecExp(CompilatorLFCParser.PostDecExpContext ctx);
	/**
	 * Exit a parse tree produced by the {@code postDecExp}
	 * labeled alternative in {@link CompilatorLFCParser#expr}.
	 * @param ctx the parse tree
	 */
	void exitPostDecExp(CompilatorLFCParser.PostDecExpContext ctx);
	/**
	 * Enter a parse tree produced by the {@code parenthesisExp}
	 * labeled alternative in {@link CompilatorLFCParser#expr}.
	 * @param ctx the parse tree
	 */
	void enterParenthesisExp(CompilatorLFCParser.ParenthesisExpContext ctx);
	/**
	 * Exit a parse tree produced by the {@code parenthesisExp}
	 * labeled alternative in {@link CompilatorLFCParser#expr}.
	 * @param ctx the parse tree
	 */
	void exitParenthesisExp(CompilatorLFCParser.ParenthesisExpContext ctx);
	/**
	 * Enter a parse tree produced by the {@code preIncExp}
	 * labeled alternative in {@link CompilatorLFCParser#expr}.
	 * @param ctx the parse tree
	 */
	void enterPreIncExp(CompilatorLFCParser.PreIncExpContext ctx);
	/**
	 * Exit a parse tree produced by the {@code preIncExp}
	 * labeled alternative in {@link CompilatorLFCParser#expr}.
	 * @param ctx the parse tree
	 */
	void exitPreIncExp(CompilatorLFCParser.PreIncExpContext ctx);
	/**
	 * Enter a parse tree produced by the {@code relationalExp}
	 * labeled alternative in {@link CompilatorLFCParser#expr}.
	 * @param ctx the parse tree
	 */
	void enterRelationalExp(CompilatorLFCParser.RelationalExpContext ctx);
	/**
	 * Exit a parse tree produced by the {@code relationalExp}
	 * labeled alternative in {@link CompilatorLFCParser#expr}.
	 * @param ctx the parse tree
	 */
	void exitRelationalExp(CompilatorLFCParser.RelationalExpContext ctx);
	/**
	 * Enter a parse tree produced by the {@code logicalExp}
	 * labeled alternative in {@link CompilatorLFCParser#expr}.
	 * @param ctx the parse tree
	 */
	void enterLogicalExp(CompilatorLFCParser.LogicalExpContext ctx);
	/**
	 * Exit a parse tree produced by the {@code logicalExp}
	 * labeled alternative in {@link CompilatorLFCParser#expr}.
	 * @param ctx the parse tree
	 */
	void exitLogicalExp(CompilatorLFCParser.LogicalExpContext ctx);
	/**
	 * Enter a parse tree produced by the {@code intLiteralExp}
	 * labeled alternative in {@link CompilatorLFCParser#expr}.
	 * @param ctx the parse tree
	 */
	void enterIntLiteralExp(CompilatorLFCParser.IntLiteralExpContext ctx);
	/**
	 * Exit a parse tree produced by the {@code intLiteralExp}
	 * labeled alternative in {@link CompilatorLFCParser#expr}.
	 * @param ctx the parse tree
	 */
	void exitIntLiteralExp(CompilatorLFCParser.IntLiteralExpContext ctx);
	/**
	 * Enter a parse tree produced by {@link CompilatorLFCParser#function_call}.
	 * @param ctx the parse tree
	 */
	void enterFunction_call(CompilatorLFCParser.Function_callContext ctx);
	/**
	 * Exit a parse tree produced by {@link CompilatorLFCParser#function_call}.
	 * @param ctx the parse tree
	 */
	void exitFunction_call(CompilatorLFCParser.Function_callContext ctx);
	/**
	 * Enter a parse tree produced by {@link CompilatorLFCParser#argument_list}.
	 * @param ctx the parse tree
	 */
	void enterArgument_list(CompilatorLFCParser.Argument_listContext ctx);
	/**
	 * Exit a parse tree produced by {@link CompilatorLFCParser#argument_list}.
	 * @param ctx the parse tree
	 */
	void exitArgument_list(CompilatorLFCParser.Argument_listContext ctx);
}