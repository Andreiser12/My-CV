using System.IO;

public class ErrorReporter
{
    private readonly string path;

    public ErrorReporter(string path)
    {
        this.path = path;
        File.WriteAllText(this.path, "");
    }

    public void Report(string message)
    {
        File.AppendAllText(this.path, message + "\n");
    }
}