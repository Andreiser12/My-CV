using Antlr4.Runtime;

public class LexerErrorListener : IAntlrErrorListener<int>
{
    private readonly ErrorReporter errorReporter;

    public LexerErrorListener(ErrorReporter errorReporter)
    {
        this.errorReporter = errorReporter;
    }

    public void SyntaxError(
    TextWriter output,
    IRecognizer recognizer,
    int offendingSymbol,
    int line,
    int charPositionInLine,
    string msg,
    RecognitionException e)
    {
        errorReporter.Report($"Eroare lexicala (linia {line}): {msg}");
    }
}

public class ParserErrorListener : BaseErrorListener
{
    private readonly ErrorReporter errorReporter;

    public ParserErrorListener(ErrorReporter errorReporter)
    {
        this.errorReporter = errorReporter;
    }

    public override void SyntaxError(TextWriter output,
     IRecognizer recognizer,
      IToken offendingSymbol,
       int line, int charPositionInLine,
        string msg,
         RecognitionException e)
    {
        errorReporter.Report(
            $"Eroare sintatica (linia {line}) {msg}"
        );
    }
}