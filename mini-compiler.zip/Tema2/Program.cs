using System;
using System.Collections.Generic;
using System.IO;
using Antlr4.Runtime;

namespace Tema2LFC
{
    public class Program
    {
        public static void Main(String[] args)
        {
            var input = File.ReadAllText("input.txt");
            var inputStream = CharStreams.fromString(input);
            ErrorReporter errorReporter = new ErrorReporter("errors.txt");

            var lexer = new CompilatorLFCLexer(inputStream);
            lexer.RemoveErrorListeners();
            lexer.AddErrorListener(new LexerErrorListener(errorReporter));

            var tokenStream = new CommonTokenStream(lexer);
            var parser = new CompilatorLFCParser(tokenStream);
            parser.RemoveErrorListeners();
            parser.AddErrorListener(new ParserErrorListener(errorReporter));

            var tree = parser.program();
            SemanticVisitor semanticVisitor = new SemanticVisitor(errorReporter);

            semanticVisitor.Visit(tree);

            semanticVisitor.PrintGlobalSymbols();
            semanticVisitor.PrintFunctionSymbols();
        }
    }

}