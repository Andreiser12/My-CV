using System;
using System.Collections.Generic;
using System.IO;
using System.IO.Pipes;
using System.Xml.Schema;
using System.Globalization;
using Antlr4.Runtime;
using Antlr4.Runtime.Misc;
using System.Diagnostics;

public class VariableSymbol
{
    public string name;
    public string type;
    public bool isConst;
    public int line;
}

public class ExprResult
{
    public string type;
    public object value;

    public ExprResult(string type, object value)
    {
        this.type = type;
        this.value = value;
    }
}

public class FunctionSymbol
{
    public string name;
    public string returnType;
    public List<string> paramTypes = new();
    public int line;

    public FunctionSymbol(string name, string returnType, List<string> paramTypes, int line)
    {
        this.name = name;
        this.returnType = returnType;
        this.paramTypes = paramTypes;
        this.line = line;
    }
}

public class SemanticVisitor : CompilatorLFCBaseVisitor<object>
{
    private readonly ErrorReporter errors;
    private Dictionary<string, VariableSymbol> globalSymbols = new();
    private Dictionary<string, VariableSymbol> localSymbols = new();
    private Dictionary<string, VariableSymbol> currentScope = new();
    private Dictionary<string, FunctionSymbol> functionSymbols = new();
    private HashSet<string> functions = new();
    private Dictionary<string, string> functionReturnType = new();
    private bool hasReturn = false;
    private string currentFunction = "global";
    private List<(string type, int line)> controlStructures = new();
    private readonly Stack<Dictionary<string, VariableSymbol>> scopes = new();

    public Dictionary<string, VariableSymbol> GetGlobalSymbols()
    {
        return globalSymbols;
    }

    public Dictionary<string, FunctionSymbol> GetFunctionSymbols()
    {
        return functionSymbols;
    }

    public void PrintGlobalSymbols()
    {
        Console.WriteLine("===== Variabile globale =====");

        if (GetGlobalSymbols().Count == 0)
        {
            Console.WriteLine("(none)");
            return;
        }

        foreach (var kv in GetGlobalSymbols())
        {
            var v = kv.Value;
            Console.WriteLine($"- nume: {v.name}, tipul variabilei: {v.type}, const: {v.isConst}, declarata la linia: {v.line}");
        }
    }

    public void PrintFunctionSymbols()
    {
        Console.WriteLine("===== Functii =====");

        if (GetFunctionSymbols().Count == 0)
        {
            Console.WriteLine("(none)");
            return;
        }

        foreach (var kv in GetFunctionSymbols())
        {
            var f = kv.Value;
            string paramsText = (f.paramTypes == null || f.paramTypes.Count == 0)
                ? "()"
                : "(" + string.Join(", ", f.paramTypes) + ")";

            Console.WriteLine($"- nume: {f.name}, tip returnat: {f.returnType}, parametri: {paramsText}, declarata la linia: {f.line}");
        }
    }


    private string PromoteNumericType(string t1, string t2)
    {
        if (t1 == "double" || t2 == "double") return "double";
        if (t1 == "float" || t2 == "float") return "float";
        return "int";
    }

    private bool IsNumeric(string s)
    {
        return s == "int" || s == "float" || s == "double";
    }

    private bool CanAssign(string target, string source)
    {
        if (target == source) return true;
        if (target == "double" && (source == "int" || source == "float")) return true;
        if (target == "float" && source == "int") return true;
        return false;
    }

    public SemanticVisitor(ErrorReporter errors)
    {
        this.errors = errors;
        scopes.Push(globalSymbols);
    }

    public override object VisitVar_decl(CompilatorLFCParser.Var_declContext context)
    {
        string name = context.ID().GetText();
        string type = context.var_type().GetText();
        bool isConst = context.CONST() != null;
        int line = context.Start.Line;

        if (CurrentScope.ContainsKey(name))
        {
            errors.Report($"Eroare semantica (linia {line}): variabila '{name}' este deja declarata in acest scope.");
            return null;
        }

        if (isConst && context.expr() == null)
        {
            errors.Report($"Eroare semantica (linia {line}): variabila const '{name}' trebuie initializata.");
        }

        CurrentScope[name] = new VariableSymbol
        {
            name = name,
            type = type,
            isConst = isConst,
            line = line
        };

        if (context.expr() != null)
        {
            var init = (ExprResult)Visit(context.expr());
            if (init != null && init.type != type)
            {
                errors.Report($"Eroare semantica (linia {line}): initializare intre tipuri diferite ({type} = {init.type}).");
            }
        }
        return null;
    }

    public override object VisitAssignment_statement(CompilatorLFCParser.Assignment_statementContext context)
    {
        string name = context.ID().GetText();
        string op = context.assign_op().GetText();
        int line = context.Start.Line;
        var rhs = (ExprResult)Visit(context.expr());

        return CheckAssignment(name, op, rhs, line);
    }

    public override object VisitAssignment_statement_no_semi(CompilatorLFCParser.Assignment_statement_no_semiContext context)
    {
        string name = context.ID().GetText();
        string op = context.assign_op().GetText();
        int line = context.Start.Line;

        var rhs = (ExprResult)Visit(context.expr());
        return CheckAssignment(name, op, rhs, line);
    }

    public override object VisitFunc_decl(CompilatorLFCParser.Func_declContext context)
    {
        string name = context.ID().GetText();
        int line = context.Start.Line;

        if (name == "main")
        {
            errors.Report($"Eroare semantica (linia {line}): nu ai voie sa redefinesti 'main' ca functie normala.");
            return null;
        }

        if (functions.Contains(name))
        {
            errors.Report(
                $"Eroare semantica (linia {line}) functia '{name}' a fost definita deja."
            );
            return null;
        }
        functions.Add(name);
        currentFunction = name;

        string retType = context.func_type().GetText();
        functionReturnType[name] = retType;

        var paramList = context.param_list();

        var symbol = new FunctionSymbol(name, retType, new List<string>(), line);
        if (paramList != null)
        {
            foreach (var p in paramList.param())
            {

                string paramType = p.var_type().GetText();
                symbol.paramTypes.Add(paramType);

                string paramName = p.ID().GetText();
                if (CurrentScope.ContainsKey(paramName))
                {
                    errors.Report($"Eroare semantica (linia {p.Start.Line}): parametrul '{paramName}' este duplicat.");
                }
                else
                {
                    CurrentScope[paramName] = new VariableSymbol
                    {
                        name = paramName,
                        type = paramType,
                        isConst = false,
                        line = p.Start.Line
                    };
                }
            }
        }
        functionSymbols[name] = symbol;
        return null;
    }

    public override object VisitReturn_statement(CompilatorLFCParser.Return_statementContext context)
    {
        int line = context.Start.Line;

        if (currentFunction == "global")
        {
            errors.Report($"Eroare semantica (linia {line}): 'return' in afara unei functii.");
            return null;
        }
        hasReturn = true;

        if (!functionReturnType.TryGetValue(currentFunction, out var retType))
            return null;

        bool hasExpr = context.expr() != null;

        if (retType == "void")
        {
            if (hasExpr)
                errors.Report($"Eroare semantica (linia {line}): functia void nu poate returna o expresie.");
            return null;
        }

        if (!hasExpr)
        {
            errors.Report($"Eroare semantica (linia {line}): functia '{currentFunction}' trebuie sa returneze '{retType}'.");
            return null;
        }

        var exprRes = (ExprResult)Visit(context.expr());
        if (exprRes != null && exprRes.type != retType)
        {
            errors.Report($"Eroare semantica (linia {line}): return incompatibil ({retType} vs {exprRes.type}).");
        }

        return null;
    }

    public override object VisitIf_statement(CompilatorLFCParser.If_statementContext context)
    {
        controlStructures.Add(("if", context.Start.Line));

        var condition = (ExprResult)Visit(context.expr());

        return VisitChildren(context);
    }

    public override object VisitWhile_statement(CompilatorLFCParser.While_statementContext context)
    {
        controlStructures.Add(("while", context.Start.Line));

        var condition = (ExprResult)Visit(context.expr());

        return VisitChildren(context);
    }

    public override object VisitFor_statement(CompilatorLFCParser.For_statementContext context)
    {
        controlStructures.Add(("for", context.Start.Line));

        scopes.Push(new Dictionary<string, VariableSymbol>());

        if (context.for_init() != null)
            Visit(context.for_init());

        if (context.for_condition() != null)
            Visit(context.for_condition());

        if (context.for_step() != null)
            Visit(context.for_step());

        Visit(context.statement());

        scopes.Pop();
        return null;
    }

    public override object VisitIntLiteralExp(
     CompilatorLFCParser.IntLiteralExpContext context)
    {
        return new ExprResult("int", int.Parse(context.GetText()));
    }

    public override object VisitStringLiteralExp(
        CompilatorLFCParser.StringLiteralExpContext context)
    {
        return new ExprResult("string", context.GetText().Trim('"'));
    }

    public override object VisitFloatLiteralExp(
        CompilatorLFCParser.FloatLiteralExpContext context)
    {
        string text = context.GetText();

        if (text.EndsWith("f") || text.EndsWith("F"))
        {
            text = text.Substring(0, text.Length - 1);
        }
        return new ExprResult("float", float.Parse(text, CultureInfo.InvariantCulture));
    }

    public override object VisitDoubleLiteralExp(
        CompilatorLFCParser.DoubleLiteralExpContext context)
    {
        return new ExprResult("double", double.Parse(context.GetText(), CultureInfo.InvariantCulture));
    }

    public override object VisitIdExp(
        CompilatorLFCParser.IdExpContext context)
    {
        string name = context.ID().GetText();
        var sym = ResolveVar(name);

        if (sym == null)
        {
            errors.Report($"Variabila {name} nu a fost declarata.");
            return null;
        }

        return new ExprResult(sym.type, null);
    }

    public override object VisitAddSubExp(
        CompilatorLFCParser.AddSubExpContext context)
    {
        var left = (ExprResult)Visit(context.expr(0));
        var right = (ExprResult)Visit(context.expr(1));

        if (left == null || right == null)
        {
            return null;
        }

        string op = context.GetChild(1).GetText();

        if (left.type == "string" && right.type == "string")
        {
            if (op == "-")
            {
                errors.Report("Nu este permisa scaderea string-urilor");
                return null;
            }
            return new ExprResult("string", null);

        }
        bool leftNumeric = left.type == "int" || left.type == "float" || left.type == "double";
        bool rightNumeric = right.type == "int" || right.type == "float" || right.type == "double";

        if (leftNumeric != rightNumeric)
        {
            errors.Report($"Eroare semantica (line {context.Start.Line}): Tipuri incompatibile la + sau -.");
            return null;
        }
        string resultType = PromoteNumericType(left.type, right.type);
        return new ExprResult(resultType, null);
    }

    public override object VisitRelationalExp(
        CompilatorLFCParser.RelationalExpContext context)
    {
        var left = (ExprResult)Visit(context.expr(0));
        var right = (ExprResult)Visit(context.expr(1));

        if (left == null || right == null)
        {
            return null;
        }

        if (IsNumeric(left.type) && IsNumeric(right.type))
        {
            return new ExprResult("bool", null);
        }

        if (left.type != right.type)
        {
            errors.Report($"Eroare semantica (linia {context.Start.Line}): Comparatie intre tipuri de date diferite.");
            return null;
        }

        return new ExprResult("bool", null);
    }

    public override object VisitLogicalExp(
        CompilatorLFCParser.LogicalExpContext context)
    {
        var left = (ExprResult)Visit(context.expr(0));
        var right = (ExprResult)Visit(context.expr(1));

        if (left == null || right == null)
        {
            return new ExprResult("bool", null);
        }

        return new ExprResult("bool", null);
    }

    public override object VisitNotExp([NotNull] CompilatorLFCParser.NotExpContext context)
    {
        var inner = (ExprResult)Visit(context.expr());
        if (inner == null)
        {
            return null;
        }

        if (inner.type != "bool")
        {
            errors.Report($"Eroare semantica (linia {context.Start.Line}): operatorul '!' se aplica doar pe bool.");
        }

        return new ExprResult("bool", null);
    }

    private ExprResult CheckIncDecOperand(CompilatorLFCParser.ExprContext expr, int line, string op)
    {
        string name = null;
        CompilatorLFCParser.ExprContext current = expr;

        if (expr is CompilatorLFCParser.IdExpContext idCtx)
        {
            name = idCtx.ID().GetText();
        }

        else if (expr is CompilatorLFCParser.PostIncExpContext ||
                expr is CompilatorLFCParser.PreIncExpContext ||
                expr is CompilatorLFCParser.PostDecExpContext ||
                expr is CompilatorLFCParser.PreDecExpContext)
        {
            errors.Report($"Eroare semantica (linia {line}): operatorul '{op}' nu poate fi aplicat pe o expresie care deja contine '++' sau '--'.");
            return null;
        }
        else
        {
            errors.Report($"Eroare semantica (linia {line}): operatorul '{op}' se poate aplica doar pe o variabila (ID).");
            return null;
        }

        var sym = ResolveVar(name);
        if (sym == null)
        {
            errors.Report($"Eroare semantica (linia {line}): variabila '{name}' nu a fost declarata.");
            return null;
        }

        if (sym.isConst)
        {
            errors.Report($"Eroare semantica (linia {line}): variabila '{name}' este const, nu poate fi modificata cu '{op}'.");
            return null;
        }

        if (!IsNumeric(sym.type))
        {
            errors.Report($"Eroare semantica (linia {line}): operatorul '{op}' se aplica doar pe tipuri numerice (int/float/double).");
            return null;
        }

        return new ExprResult(sym.type, null);
    }

    public override object VisitIncrement_statement(CompilatorLFCParser.Increment_statementContext context)
    {
        if (context.ID() == null)
        {
            return null;
        }
        int line = context.Start.Line;
        string name = context.ID().GetText();

        var sym = ResolveVar(name);
        if (sym == null)
        {
            errors.Report($"Eroare semantica (linia {line}): variabila '{name}' nu a fost declarata.");
            return null;
        }
        if (sym.isConst)
        {
            errors.Report($"Eroare semantica (linia {line}): variabila '{name}' este constanta.");
            return null;
        }
        if (!IsNumeric(sym.type))
        {
            errors.Report($"Eroare semantica (linia {line}): operatorul '++' se aplica doar pe tipuri numerice.");
            return null;
        }
        return null;
    }

    public override object VisitDecrement_statement(CompilatorLFCParser.Decrement_statementContext context)
    {
        if (context.ID() == null)
        {
            return null;
        }
        string name = context.ID().GetText();
        int line = context.Start.Line;

        var sym = ResolveVar(name);
        if (sym == null)
        {
            errors.Report($"Eroare semantica (linia {line}): variabila '{name}' nu a fost declarata.");
            return null;
        }
        if (sym.isConst)
        {
            errors.Report($"Eroare semantica (linia {line}): variabila '{name}' este constanta.");
            return null;
        }
        if (!IsNumeric(sym.type))
        {
            errors.Report($"Eroare semantica (linia {line}): operatorul '--' se aplica doar pe tipuri numerice.");
            return null;
        }
        return null;
    }

    public override object VisitPreIncExp(CompilatorLFCParser.PreIncExpContext context)
    {
        return CheckIncDecOperand(context.expr(), context.Start.Line, "++");
    }

    public override object VisitPostIncExp(CompilatorLFCParser.PostIncExpContext context)
    {
        return CheckIncDecOperand(context.expr(), context.Start.Line, "++");
    }

    public override object VisitPreDecExp(CompilatorLFCParser.PreDecExpContext context)
    {
        return CheckIncDecOperand(context.expr(), context.Start.Line, "--");
    }

    public override object VisitPostDecExp(CompilatorLFCParser.PostDecExpContext context)
    {
        return CheckIncDecOperand(context.expr(), context.Start.Line, "--");
    }

    public override object VisitEqualityExp(CompilatorLFCParser.EqualityExpContext context)
    {
        var left = (ExprResult)Visit(context.expr(0));
        var right = (ExprResult)Visit(context.expr(1));

        if (left == null || right == null)
        {
            return null;
        }

        if (IsNumeric(left.type) && IsNumeric(right.type))
        {
            return new ExprResult("bool", null);
        }

        if (left.type != right.type)
        {
            errors.Report($"Eroare semantica (linia {context.Start.Line}): '=='/'!=' intre tipuri diferite.");
            return null;
        }

        return new ExprResult("bool", null);
    }

    private object CheckAssignment(string name, string op, ExprResult rhs, int line)
    {
        var sym = ResolveVar(name);
        if (sym == null)
        {
            errors.Report($"Eroare semantica (linia {line}): variabila '{name}' nu a fost declarata.");
            return null;
        }

        if (sym.isConst)
        {
            errors.Report($"Eroare semantica (linia {line}): variabila '{name}' este const, nu poate fi modificata.");
            return null;
        }

        if (rhs == null)
        {
            return null;
        }

        bool isNumeric = IsNumeric(sym.type);
        bool isRhsNumeric = IsNumeric(rhs.type);

        switch (op)
        {
            case "=":
                {
                    if ((isNumeric && !isRhsNumeric) || (!isNumeric && isRhsNumeric))
                    {
                        errors.Report($"Eroare semantica (linia {line}): asignare intre string si non-string ({sym.type} != {rhs.type}).");
                        return null;
                    }
                    if (!isNumeric && !isRhsNumeric)
                    {
                        return new ExprResult("string", null);
                    }
                    if (sym.type == "int" && rhs.type != "int")
                    {
                        errors.Report($"Eroare semantica (linia) {line}: asignare intre int si non-int ({sym.type} != {rhs.type})");
                        return null;
                    }
                    string resultType = PromoteNumericType(sym.type, rhs.type);
                    return new ExprResult(resultType, null);
                }
            case "+=":
                {
                    if (IsNumeric(sym.type) && IsNumeric(rhs.type))
                    {
                        if (!CanAssign(sym.type, rhs.type))
                        {
                            errors.Report($"Eroare semantina (linia {line}): Conversie implicita invalida ({sym.type}, {rhs.type})");
                            return null;
                        }
                        return new ExprResult(sym.type, null);
                    }
                    if (sym.type == "string" && rhs.type == "string")
                    {
                        return new ExprResult("string", null);
                    }
                    errors.Report($"Eroare semantica (linia {line}): '+=' invalid intre {sym.type} si {rhs.type}");
                    return null;
                }

            case "-=":
            case "*=":
            case "/=":
                {
                    if (sym.type == "string" && rhs.type == "string")
                    {
                        errors.Report($"Eroare semantica (linia {line}): {op} este invalid pentru string-uri");
                        return null;
                    }

                    if (!IsNumeric(sym.type) || !IsNumeric(rhs.type))
                    {
                        errors.Report($"Eroare semantica (linia {line}): {op} este invalid intre {sym.type} si {rhs.type}");
                        return null;
                    }
                    if (!CanAssign(sym.type, rhs.type))
                    {
                        errors.Report($"Eroare semantica (linia {line}): conversie implicita invalida {sym.type} si {rhs.type}");
                        return null;

                    }
                    if (op == "/=" && rhs.value != null && rhs.value.Equals(0))
                    {
                        errors.Report($"Eroare semantica (linia {line}): impartire la 0");
                        return null;
                    }
                    return new ExprResult(sym.type, null);
                }
            case "%=":
                {
                    if (sym.type == "string" && rhs.type == "string")
                    {
                        errors.Report($"Eroare semantia (linia {line}): {op} este invalid pentru string-uri.");
                        return null;
                    }
                    if (!IsNumeric(sym.type) || !IsNumeric(rhs.type))
                    {
                        errors.Report($"Eroare semantica (linia {line}): {op} este invalid intre {sym.type} si {rhs.type}");
                        return null;
                    }
                    if (sym.type != "int" || rhs.type != "int")
                    {
                        errors.Report($"Eroare semantica (linia {line}): {op} este invalid pentru tipuri numerice non-int");
                        return null;
                    }
                    return new ExprResult("int", null);
                }

            default:
                errors.Report($"Eroare semantica (linia {line}): operator de asignare necunoscut '{op}'.");
                return null;
        }
    }

    public override object VisitMulDivModExp(CompilatorLFCParser.MulDivModExpContext context)
    {
        var left = (ExprResult)Visit(context.expr(0));
        var right = (ExprResult)Visit(context.expr(1));
        string op = context.GetChild(1).GetText();

        if (left == null || right == null) return null;

        bool leftNumeric = IsNumeric(left.type);
        bool rightNumeric = IsNumeric(right.type);

        if (!leftNumeric || !rightNumeric)
        {
            errors.Report($"Eroare semantica (linia {context.Start.Line}): operatia {op} este invalida asupra string-urilor");
            return null;
        }

        if (leftNumeric && rightNumeric)
        {
            if (op == "%" && (left.type != "int" || right.type != "int"))
            {
                errors.Report($"Eroare semantica (linia {context.Start.Line}): Aplicarea operatiei {op} (MOD) pe tipuri non-int.");
                return null;
            }

            if (op == "/" && right.value != null && right.value.Equals(0))
            {
                errors.Report($"Eroare sematnica (linia {context.Start.Line}): Impartire la 0.");
                return null;
            }
        }
        string resultType = PromoteNumericType(left.type, right.type);

        return new ExprResult(resultType, null);
    }

    public override object VisitBlock(CompilatorLFCParser.BlockContext context)
    {
        scopes.Push(new Dictionary<string, VariableSymbol>());
        var result = VisitChildren(context);
        scopes.Pop();
        return result;
    }

    public override object VisitFunction(CompilatorLFCParser.FunctionContext context)
    {
        scopes.Push(new Dictionary<string, VariableSymbol>());
        hasReturn = false;
        Visit(context.func_decl());
        Visit(context.block());

        string funcName = context.func_decl().ID().GetText();
        if (functionReturnType.TryGetValue(funcName, out var retType))
        {
            if (retType != "void" && !hasReturn)
            {
                errors.Report($"Eroare semantica (linia {context.Start.Line}): functia '{funcName}' nu contine valoare returnata.");
            }
        }

        scopes.Pop();
        currentFunction = "global";
        return null;
    }

    public override object VisitMain_function(CompilatorLFCParser.Main_functionContext context)
    {
        if (functionSymbols.ContainsKey("main"))
        {
            errors.Report($"Eroare semantica (line {context.Start.Line}): Functia 'main' a fost definita deja.");
            return null;
        }
        currentFunction = "main";
        var funcSymbol = new FunctionSymbol(currentFunction, "int", new List<string>(), context.Start.Line);
        functionSymbols.Add(currentFunction, funcSymbol);
        functionReturnType["main"] = "int";
        hasReturn = false;
        scopes.Push(new Dictionary<string, VariableSymbol>());
        Visit(context.block());
        scopes.Pop();

        if (!hasReturn)
        {
            errors.Report($"Eroare semantica (linia {context.Start.Line}): funcita 'main' trebuie sa contina instructiune return.");
        }
        currentFunction = "global";
        return null;
    }

    public override object VisitFunction_call(CompilatorLFCParser.Function_callContext context)
    {
        string name = context.ID().GetText();
        int line = context.Start.Line;

        if (!functionSymbols.TryGetValue(name, out var fn))
        {
            errors.Report($"Eroare semantica (linia {line}): functia '{name}' nu a fost declarata.");
            return null;
        }

        var args = new List<ExprResult>();
        var argList = context.argument_list();
        if (argList != null)
        {
            foreach (var e in argList.expr())
            {
                var r = (ExprResult)Visit(e);
                args.Add(r);
            }
        }

        int expected = fn.paramTypes.Count;
        int received = args.Count;

        if (expected != received)
        {
            errors.Report($"Eroare semantica (linia {line}): functia '{name}' asteapta {expected} argument(e), dar ai dat {received}.");
            return new ExprResult(fn.returnType, null);
        }

        for (int i = 0; i < expected; i++)
        {
            var arg = args[i];
            if (arg == null) continue;

            string expectedType = fn.paramTypes[i];
            if (arg.type != expectedType)
            {
                errors.Report($"Eroare semantica (linia {line}): argumentul {i + 1} la '{name}' are tipul {arg.type}, dar se asteapta {expectedType}.");
            }
        }

        return new ExprResult(fn.returnType, null);
    }

    private Dictionary<string, VariableSymbol> CurrentScope => scopes.Peek();

    private VariableSymbol ResolveVar(string name)
    {
        foreach (var scope in scopes.ToArray())
        {
            if (scope.ContainsKey(name))
            {
                return scope[name];
            }
        }
        return null;
    }

    public override object VisitFor_init(CompilatorLFCParser.For_initContext context)
    {
        return VisitChildren(context);
    }

    public override object VisitFor_condition(CompilatorLFCParser.For_conditionContext context)
    {
        if (context.expr() != null)
        {
            var condition = (ExprResult)Visit(context.expr());
            if (condition != null && condition.type != "bool")
            {
                errors.Report($"Eroare semantica (linia {context.Start.Line}): conditia din structura 'for' trebuie sa aiba tipul de date 'bool");
            }
        }

        return new ExprResult("bool", null);
    }

    public override object VisitFor_step(CompilatorLFCParser.For_stepContext context)
    {
        return VisitChildren(context);
    }

    public override object VisitParenthesisExp(CompilatorLFCParser.ParenthesisExpContext context)
    {
        return Visit(context.expr());
    }
}